
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class AnguloManecillasReloj01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int MAX_HORAS = 12;
            final int MAX_GRADOS = 360;
            final int MAX_MINUTOS = 60;
            final int GRADOS_POR_HORA = MAX_GRADOS / MAX_HORAS;
            final int GRADOS_POR_MIN = MAX_GRADOS / MAX_MINUTOS ;
            
            // Variables de entrada
            int hora, minuto;


            // Variables de salida
            int gradosEntreHoraMinuto;


            // Variables auxiliares
            int gradosHora;
            int gradosMinuto;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL �NGULO ENTRE MANECILLAS DEL RELOJ");
            System.out.println("---------------------------------------------");
            System.out.println("Introduzca hora y minuto: ");
            hora = teclado.nextInt();
            minuto = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            gradosHora   = hora   * GRADOS_POR_HORA;
            gradosMinuto = minuto * GRADOS_POR_MIN;
            
            gradosEntreHoraMinuto = Math.abs(gradosHora - gradosMinuto) ;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El �ngulo formado entre las manecillas de hora y minuto es de:");
            System.out.printf  ("%d grados\n", gradosEntreHoraMinuto);
        
	}
    
}