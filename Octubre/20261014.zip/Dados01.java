
package ejemplos;

/**
 * Programa JUEGO DE P�QUER
 * @author diosdado
 */

import java.util.Scanner;


public class Dados01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dado1, dado2, dado3, dado4;



            // Variables de salida
            boolean pareja;
            boolean trio;
            boolean doblePareja;
            boolean poker;
            boolean sinJugada;
            
            double puntuacionMedia;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE P�QUER");
            System.out.println("---------------");
            System.out.println("Introduzca valor obtenido en cada dado:");
            dado1 = teclado.nextInt();
            dado2 = teclado.nextInt();
            dado3 = teclado.nextInt();
            dado4 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Caluclamos cada posible jugada (unas pueden incluir a otras)
            
            // Pareja: basta con que haya dos dados iguales
            // (cualquier combinaci�n: 1=2, 1=3, 1=4, 2=3, 2=4, 3=4
            pareja = 
                    dado1 == dado2 || dado1 == dado3 || dado1 == dado4 ||
                    dado2 == dado3 || dado2 == dado4 || dado3 == dado4;

            // Doble pareja: basta con que dos dados sean iguales
            // y los tros dos tambi�n
            // (cualquier combinaci�n: 1-2 y 3-4; 1-3 y 2-4; 1-4 y 2-3
            doblePareja = 
                    (dado1 == dado2 && dado3 == dado4) ||
                    (dado1 == dado3 && dado2 == dado4) ||
                    (dado1 == dado4 && dado2 == dado3) ;

            // Tr�o: tres deben ser iguales
            // (cualquier combinaci�n de 1-2-3, 2-3-4, 1-3-4, 1-2-4
            trio =
                    dado1 == dado2 && dado2 == dado3 ||
                    dado2 == dado3 && dado3 == dado4 ||
                    dado1 == dado3 && dado3 == dado4 ||
                    dado1 == dado2 && dado2 == dado4 ;

            // P�ker: los cuatro dados deben ser iguales
            // Sola una posibilidad para comprobar
            poker = 
                    (dado1 == dado2) && dado2 == dado3 && dado3 == dado4 ;

            // Ahora refinamos para que solamente pueda haber una jugada:
            trio = trio && !poker; // Si hay poker, descartamos el tr�o (lo incluye)
            doblePareja = doblePareja && !poker ; // Si hay poker, descartamos la posible doble pareja (la incluir�a)
            pareja = pareja && !poker && !trio && !doblePareja; // Si hay poker, doble pareja o trio, descartamos la pareja (la incluye)           
            sinJugada = !pareja && ! doblePareja && !trio && !poker; // Si no hay pareja, ni doble pareja, ni tr�o, ni poker, no hay jugada
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("Jugada obtenida en el lanzamiento: ");
            System.out.printf ("Pareja: %s\n", pareja);
            System.out.printf ("Doble pareja: %s\n", doblePareja);
            System.out.printf ("Tr�o: %s\n", trio);
            System.out.printf ("P�ker: %s\n", poker);
            System.out.printf ("Sin jugada: %s\n", sinJugada);

        
	}
    
}