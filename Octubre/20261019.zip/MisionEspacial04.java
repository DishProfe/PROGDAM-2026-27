
package ejemplos2026;

/**
 * Programa CONTROL DE UNA MISION ESPACIAL
 * @author diosdado
 */

import java.util.Scanner;


public class MisionEspacial04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int OXIGENO_CRITICO = 20;
            final int OXIGENO_MINIMO = 60;
            final int OXIGENO_OPTIMO = 85;
            final int COMBUSTIBLE_CRITICO = 10;
            final int COMBUSTIBLE_MINIMO = 40;
            final int COMBUSTIBLE_OPTIMO = 80;
            final int ENERGIA_CRITICA = 15;
            final int ENERGIA_MINIMA = 50;
            final int ENERGIA_OPTIMA = 80;
            final double TEMPERATURA_EMERGENCIA_MIN = 5.0;
            final double TEMPERATURA_EMERGENCIA_MAX = 35.0;
            final double TEMPERATURA_MIN = 10.0;
            final double TEMPERATURA_MAX = 30.0;
            final double TEMPERATURA_OPTIMA_MIN = 18.0;
            final double TEMPERATURA_OPTIMA_MAX = 24.0;

            // Variables de entrada
            int combustible, oxigeno, energia;
            double temperatura;

            // Variables de salida
            boolean emergenciaCritica;
            boolean falloSoporteVital;
            boolean lanzamientoRestringido;
            boolean lanzamientoAutorizado;
            boolean lanzamientoOptimo;
            String resultado;

            // Variables auxiliares
            boolean hayEmergencia;
            boolean hayFalloSoporte;
            boolean cumpleMinimos;
            boolean cumpleOptimos;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTROL DE UNA MISION ESPACIAL");
            System.out.println("------------------------------");
            System.out.print("Combustible (0-100): ");
            combustible = teclado.nextInt();
            System.out.print("Oxigeno (0-100): ");
            oxigeno = teclado.nextInt();
            System.out.print("Energia (0-100): ");
            energia = teclado.nextInt();
            System.out.print("Temperatura (grados C): ");
            temperatura = teclado.nextDouble();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Mensaje final en forma de texto
            // Con solo una de las cinco posibles categor�as de salida
            
            // A. Emergencia cr�tica: ox�geno cr�tico, temperatura extrema
            // o dos fallos graves simult�neos (combustible y energ�a por debajo
            // del valor cr�tico)
            if ( oxigeno < OXIGENO_CRITICO ||
                    temperatura  < TEMPERATURA_EMERGENCIA_MIN || temperatura > TEMPERATURA_EMERGENCIA_MAX ||
                    (combustible < COMBUSTIBLE_CRITICO && energia < ENERGIA_CRITICA) 
               ) {
                resultado = "EMERGENCIA CR�TICA: lanzamiento prohibido"; 
            } else {
                // B. Fallo del soporte vital: ox�geno por debajo del m�nimo
                // o energ�a por debajo de la cr�tica
                if ( oxigeno < OXIGENO_MINIMO || energia < ENERGIA_CRITICA ) {
                    resultado = "FALLO DEL SOPORTE VITAL: lanzamiento prohibido";
                } else {
                    // C. Requisitos m�nimos para el lanzamiento
                    if ( !(combustible >= COMBUSTIBLE_MINIMO &&
                        oxigeno >= OXIGENO_MINIMO &&
                        energia >= ENERGIA_MINIMA &&
                        temperatura >= TEMPERATURA_MIN && temperatura <= TEMPERATURA_MAX) 
                        ) {
                            resultado = "LANZAMIENTO RESTRINGIDO: no se cumplen los requisitos m�nimos";
                    } else {
                        // D. Condiciones �ptimas
                        if ( combustible >= COMBUSTIBLE_OPTIMO &&
                             oxigeno >= OXIGENO_OPTIMO &&
                             energia >= ENERGIA_OPTIMA &&
                             temperatura >= TEMPERATURA_OPTIMA_MIN &&
                             temperatura <= TEMPERATURA_OPTIMA_MAX 
                            ) {
                                resultado = "LANZAMIENTO �PTIMO: todos los par�metros est�n en su nivel �ptimo";
                        } else {
                            // E. Si las condiciones no son �ptimas y no hab�as fallos
                            // al menos hay condiciones m�nimas para lanzamiento
                                resultado = "LANZAMIENTO AUTORIZADO: sistemas dentro de los m�rgenes permitidos";
                        }
                    }
                }
            }
            

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            //System.out.println("Emergencia critica: " + emergenciaCritica);
            //System.out.println("Fallo del soporte vital: " + falloSoporteVital);
            //System.out.println("Lanzamiento restringido: " + lanzamientoRestringido);
            //System.out.println("Lanzamiento autorizado: " + lanzamientoAutorizado);
            //System.out.println("Lanzamiento optimo: " + lanzamientoOptimo);

            System.out.println (resultado);
            
	}
    
}