
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class NotaCualtitativa01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double notaNumerica;



            // Variables de salida
            String notaTexto;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CALFICACI�N CUALITATIVA");
            System.out.println("-----------------------");
            System.out.print("Introduzca calificaci�n cuantitativa (0-10): ");

            notaNumerica = teclado.nextDouble();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( notaNumerica < 2.0 ) {
                notaTexto = "MUY DEFICIENTE";
            } else {
                if ( notaNumerica < 5.0 ) {
                    notaTexto = "INSUFICIENTE";                    
                } else {
                    if ( notaNumerica < 6.0 ) {
                        notaTexto = "SUFICIENTE";
                    } else {
                        if ( notaNumerica < 7.0 ) {
                            notaTexto = "BIEN";
                        } else {
                            if ( notaNumerica < 9.0 ) {
                                notaTexto = "NOTABLE";
                            } else {
                                notaTexto = "SOBRESALIENTE";
                            }
                        }
                    }
                }
                
            }




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("La nota cualitativa equivalente es: %s\n", notaTexto);


        
	}
    
}