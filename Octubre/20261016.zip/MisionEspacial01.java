
package ejemplos;

/**
 * Programa CONTROL DE UNA MISION ESPACIAL
 * @author diosdado
 */

import java.util.Scanner;


public class MisionEspacial01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int OXIGENO_CRITICO = 20;
            final int OXIGENO_MINIMO = 60;
            final int OXIGENO_OPTIMO = 85;
            final int COMBUSTIBLE_CRITICO = 10;
            final int COMBUSTIBLE_MINIMO = 40;
            final int COMBUSTIBLE_OPTIMO = 80;
            final int ENERGIA_CRITICA = 15;
            final int ENERGIA_MINIMA = 50;
            final int ENERGIA_OPTIMA = 80;
            final double TEMPERATURA_EMERGENCIA_MIN = 5.0;
            final double TEMPERATURA_EMERGENCIA_MAX = 35.0;
            final double TEMPERATURA_MIN = 10.0;
            final double TEMPERATURA_MAX = 30.0;
            final double TEMPERATURA_OPTIMA_MIN = 18.0;
            final double TEMPERATURA_OPTIMA_MAX = 24.0;

            // Variables de entrada
            int combustible, oxigeno, energia;
            double temperatura;

            // Variables de salida
            boolean emergenciaCritica;
            boolean falloSoporteVital;
            boolean lanzamientoRestringido;
            boolean lanzamientoAutorizado;
            boolean lanzamientoOptimo;
            String resultado;

            // Variables auxiliares
            boolean hayEmergencia;
            boolean hayFalloSoporte;
            boolean cumpleMinimos;
            boolean cumpleOptimos;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTROL DE UNA MISION ESPACIAL");
            System.out.println("------------------------------");
            System.out.print("Combustible (0-100): ");
            combustible = teclado.nextInt();
            System.out.print("Oxigeno (0-100): ");
            oxigeno = teclado.nextInt();
            System.out.print("Energia (0-100): ");
            energia = teclado.nextInt();
            System.out.print("Temperatura (grados C): ");
            temperatura = teclado.nextDouble();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // A. Emergencia cr�tica: ox�geno cr�tico, temperatura extrema
            // o dos fallos graves simult�neos.
            hayEmergencia = 
                    oxigeno < OXIGENO_CRITICO ||
                    temperatura  < TEMPERATURA_EMERGENCIA_MIN || temperatura > TEMPERATURA_EMERGENCIA_MAX ||
                    (combustible < COMBUSTIBLE_CRITICO && energia < ENERGIA_CRITICA) ;

            // B. Fallo del soporte vital: ox�geno bajo, energ�a baja
            hayFalloSoporte = 
                    oxigeno < OXIGENO_MINIMO ||
                    energia < ENERGIA_CRITICA;
        
            // C. Requisitos m�nimos para el lanzamiento
            cumpleMinimos = 
                    combustible >= COMBUSTIBLE_MINIMO &&
                    oxigeno >= OXIGENO_MINIMO &&
                    energia >= ENERGIA_MINIMA &&
                    temperatura >= TEMPERATURA_MIN && temperatura <= TEMPERATURA_MAX;
            
            // D. Condiciones �ptimas
            cumpleOptimos = 
                    combustible >= COMBUSTIBLE_OPTIMO &&
                    oxigeno >= OXIGENO_OPTIMO &&
                    energia >= ENERGIA_OPTIMA &&
                    temperatura >= TEMPERATURA_OPTIMA_MIN &&
                    temperatura <= TEMPERATURA_OPTIMA_MAX ;

            // Refinamos las categor�as para que solo una sea verdadera
            emergenciaCritica = hayEmergencia;
            
            // Se considera fallo de soporte vital si se dan sus condiciones y 
            // no hay emergencia cr�tica, que es peor
            falloSoporteVital = !emergenciaCritica && hayFalloSoporte;
            
            // Se considera lanzamiento restringido si no hay emergencia cr�tica 
            // ni fallo de soporte vital, pero no se dan las condiciones m�nimas
            // para el lanzamiento
            lanzamientoRestringido = 
                    !emergenciaCritica &&
                    !falloSoporteVital &&
                    !cumpleMinimos;

            // Se considera lanzamiento �ptimo si no hay emergencia cr�tica
            // ni fallo de soporte vital y adem�s se cumplen las condiciones m�nimas
            lanzamientoOptimo =
                    !emergenciaCritica &&
                    !falloSoporteVital &&                    
                    cumpleMinimos &&
                    cumpleOptimos;

            // Se considera lanzamiento autorizado (pero no �ptimo) si 
            // si no hay emergencia cr�tica ni fallo de soporte vital y se cumplen 
            // las condiciones m�nimas, pero no se llega a las �ptimas
            lanzamientoAutorizado = 
                    !emergenciaCritica &&
                    !falloSoporteVital &&                    
                    cumpleMinimos &&
                    !cumpleOptimos;

            // Mensaje final en forma de texto
            // Con solo una de las cinco posibles categor�as de salida
            resultado =
                    emergenciaCritica ? "EMERGENCIA CR�TICA: lanzamiento prohibido" 
                    : falloSoporteVital ? "FALLO DEL SOPORTE VITAL: lanzamiento prohibido" 
                    : lanzamientoRestringido ? "LANZAMIENTO RESTRINGIDO: no se cumplen los requisitos m�nimos" 
                    : lanzamientoOptimo ? "LANZAMIENTO �PTIMO: todos los par�metros est�n en su nivel �ptimo" 
                    : "LANZAMIENTO AUTORIZADO: sistemas dentro de los m�rgenes permitidos";   
                    

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            //System.out.println("Emergencia critica: " + emergenciaCritica);
            //System.out.println("Fallo del soporte vital: " + falloSoporteVital);
            //System.out.println("Lanzamiento restringido: " + lanzamientoRestringido);
            //System.out.println("Lanzamiento autorizado: " + lanzamientoAutorizado);
            //System.out.println("Lanzamiento optimo: " + lanzamientoOptimo);

            System.out.println (resultado);
            
	}
    
}