
package ejemplos;

/**
 * Programa IMPRESION DE P�GINAS
 * @author diosdado
 */

import java.util.Scanner;


public class Impresora01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numPaginas;



            // Variables de salida
            int  numHojas;
            boolean ultimaEnBlanco;
            int totalPaginas;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("IMPRESION DE P�GINAS");
            System.out.println("--------------------");
            System.out.println("Introduzca el n�mero de p�ginas: ");
            numPaginas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            numHojas = numPaginas / 2 +  (numPaginas % 2);
            ultimaEnBlanco = numPaginas % 2 == 1;
            totalPaginas = numPaginas;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("Cu�ntas hojas ser�an necesarias si se imprimieran a doble cara: " + numHojas);
            System.out.println("Hay cara en blanco al final de la �ltima hoja: " + ultimaEnBlanco);
            System.out.println("Total de p�ginas impresas: " + numPaginas);
        
	}
    
}