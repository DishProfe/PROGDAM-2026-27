
package ejemplos;

/**
 * Programa BUSCAR UNA CIFRA EN UN N�MERO
 * @author diosdado
 */

import java.util.Scanner;


public class BuscarCifra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;
            int cifraBuscada;



            // Variables de salida
            int vecesCifra;


            // Variables auxiliares
            int cifra;
            int residuo;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("BUSCAR UNA CIFRA EN UN N�MERO");
            System.out.println("-----------------------------");
            System.out.println("Introduzca n�mero de cinco cifras:");
            numero = teclado.nextInt();
            System.out.println("Introduzca cifra de b�squeda:");
            cifraBuscada = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            vecesCifra = 0;

            // Compruebo la primera cifra (unidades)
            cifra   = numero % 10 ;
            residuo = numero / 10 ;
            vecesCifra = cifraBuscada == cifra ? vecesCifra+1 : vecesCifra;

            // Compruebo la segunda cifra (decenas)
            cifra   = residuo % 10 ;
            residuo = residuo / 10 ;
            vecesCifra = cifraBuscada == cifra ? vecesCifra+1 : vecesCifra;
            
            // Compruebo la tercera cifra (centenas)
            cifra   = residuo % 10 ;
            residuo = residuo / 10 ;
            vecesCifra = cifraBuscada == cifra ? vecesCifra+1 : vecesCifra;

             // Compruebo la cuarta cifra (unidades de millar)
            cifra   = residuo % 10 ;
            residuo = residuo / 10 ;
            vecesCifra = cifraBuscada == cifra ? vecesCifra+1 : vecesCifra;

             // Compruebo la quinta cifra (decenas de millar)
            cifra   = residuo;
            vecesCifra = cifraBuscada == cifra ? vecesCifra+1 : vecesCifra;

             
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("N�mero de veces que est� la cifra %d en el n�mero %d: %d\n",
                    cifraBuscada, numero, vecesCifra);


        
	}
    
}