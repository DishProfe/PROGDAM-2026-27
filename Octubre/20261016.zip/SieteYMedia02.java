
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class SieteYMedia02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int naipe1, naipe2, naipe3;


            // Variables de salida
            boolean esSieteYMedia;


            // Variables auxiliares
            double valor1, valor2, valor3;
            double suma;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE LAS SIETE Y MEDIA");
            System.out.println("--------------------------");
            System.out.println("Introduzca el valor de los tres naipes: ");
            naipe1 = teclado.nextInt();
            naipe2 = teclado.nextInt();
            naipe3 = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            valor1 = naipe1<=7 ? naipe1 : 0.5;
            valor2 = naipe2<=7 ? naipe2 : 0.5;
            valor3 = naipe3<=7 ? naipe3 : 0.5;
  
            suma = valor1 + valor2 + valor3;

            
            esSieteYMedia = suma == 7.50;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Los naipes suman siete y medio: " + (esSieteYMedia ? "s�" : "no") );

        
	}
    
}