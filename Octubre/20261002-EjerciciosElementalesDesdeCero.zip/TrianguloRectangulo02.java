package ejemplos2025;
import ejemplos2024.*;
import ejemplos2023.*;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class TrianguloRectangulo02 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        double base, altura;
        
        // Variables de salida
        double superficie, perimetro;
        
        // Variables auxiliares
        double hipotenusa;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE PERÍMETRO Y SUPERFICIE DE TRIÁNGULOS RECTÁNGULOS");
        System.out.println ("-----------------------------------------------------------");
        
        System.out.print ("Introduzca base (m): ");
        base = teclado.nextDouble();
        
        System.out.print ("Introduzca altura (m): ");
        altura = teclado.nextDouble();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del triángulo
        superficie = base * altura / 2;

        // Cálculo del perímetro del triángulo
        hipotenusa = Math.sqrt ( base*base + altura*altura );
        perimetro = base + altura + hipotenusa;
        
        // Pasamos a centímetros
        perimetro = perimetro * 100;
        superficie = superficie * 100*100;
        
        
        // Salida de resultados
        // --------------------
        System.out.print ("Superficie: ");
        System.out.print ( superficie );
        System.out.println ( " cm2" );
        
        
        System.out.print ("Perímetro: ");
        System.out.print ( perimetro );
        System.out.println ( " cm" );
        
        
    }

}
