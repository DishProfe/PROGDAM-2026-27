
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemploOperadores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("1.5.2.EJEMPLOS DE OPERADORES");
            System.out.println("----------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            int a = 34;
            int b = 21;
            int c = a++ + ++b;   // c= 34 + 22 = 56, a=35, b=22
            int d = --a + --b + c--;     // d= 34 + 21 + 56 = 111, a=34, b=21, c=55
            int e = a + +b + +c + d--;   // e= 34 + 21 + 55 + 111 = 221 , a=34, b=21, c=55, d=110
            int f = -a + b-- + -c - d++;  // f= -34 + 21 - 55 - 110 = -178, a=34, b=20, d=111
            int sum = a + b + c + d + e + f;  // sum= 34 + 20 + 55 + 111 + 221 - 178 = 263 
            System.out.println("sum = " + sum);

        
	}
    
}