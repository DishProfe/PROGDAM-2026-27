
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class NombreMasLargo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String nombre1, nombre2;



            // Variables de salida
            String nombreMasLargo;


            // Variables auxiliares
            int longNombre1, longNombre2;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL NOMBRE M�S LARGO");
            System.out.println("----------------------------");
            System.out.println("Introduzca primer nombre: ");
            nombre1 = teclado.nextLine();
            System.out.println("Introduzca segundo nombre: ");
            nombre2 = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            longNombre1 = nombre1.length();
            longNombre2 = nombre2.length();

            // Opci�n 1
            if (longNombre1 >= longNombre2) {
                nombreMasLargo = nombre1;
            } else {
                nombreMasLargo = nombre2;                
            }

            // Opci�n 2
            nombreMasLargo =  longNombre1 >= longNombre2 ? nombre1 : nombre2;
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El nombre m�s largo es: %s\n", nombreMasLargo);

        
	}
    
}