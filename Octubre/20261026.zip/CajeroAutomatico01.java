
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CajeroAutomatico01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int CODIGO = 6767;
            final int MAX_INTENTOS = 3;
            

            // Variables de entrada
            int codigoIntroducido;



            // Variables de salida



            // Variables auxiliares
            boolean codigoCorrecto;
            int numIntentos;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ENTRADA AL CAJERO");
            System.out.println("-----------------");
            
            numIntentos = 0;
            do {
                // Introducci�n del PIN por teclado
                System.out.println("Introduzca PIN:");
                codigoIntroducido = teclado.nextInt();
                numIntentos++;
                
                // Comprobaci�n de c�digo correcto
                codigoCorrecto = codigoIntroducido == CODIGO;               
                if ( !codigoCorrecto ) {
                    System.out.println("PIN incorrecto\n");
                }
                
            } while ( !codigoCorrecto && numIntentos < MAX_INTENTOS );
            
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( codigoCorrecto ) {
                System.out.println ("Bienvenido al sistema...");
            } else {
                System.out.printf ("Introducido c�digo incorrecto %d veces\n",
                        numIntentos);                
                System.out.println ("Llamando a la polic�a...");                
            }
        
	}
    
}