
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemploOperadores03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("1.5.2.EJEMPLOS DE FORMATOS CON PRINTF");
            System.out.println("-------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            double a = 34;
            double b = 21;
            double c = a++ + ++b;   // c= 34 + 22 = 56, a=35, b=22
            double d = --a + --b + c--;     // d= 34 + 21 + 56 = 111, a=34, b=21, c=55
            double e = a + +b + +c + d--;   // e= 34 + 21 + 55 + 111 = 221 , a=34, b=21, c=55, d=110
            double f = -a + b-- + -c - d++;  // f= -34 + 21 - 55 - 110 = -178, a=34, b=20, d=111
            double sum = a + b + c + d + e + f;  // sum= 34 + 20 + 55 + 111 + 221 - 178 = 263 
            System.out.printf ("a= %7f, b= %7f, c= %7f\n", a, b, c);
            System.out.printf ("d= %7f, e= %7f, f= %7f\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %7.2f, b= %7.2f, c= %7.2f\n", a, b, c);
            System.out.printf ("d= %7.2f, e= %7.2f, f= %7.2f\n", d, e, f);
            System.out.println ();
            System.out.println ();
            System.out.printf ("sum = %f \n", sum);

        
	}
    
}