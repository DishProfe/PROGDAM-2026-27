
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CifraAPalabra02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;


            // Variables de salida
            String numeroPalabra;

            // Variables auxiliares
            boolean entradaValida;
            int c1, c2;
            String cifraPalabra;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TRANSFORMACI�N DE CIFRA A PALABRA");
            System.out.println("---------------------------------");
            
            do {
                System.out.println("Introduzca n�mero de dos cifra (10-99)");
                numero = teclado.nextInt();
                entradaValida = numero>=10 && numero<=99;
                if ( !entradaValida ) {
                    System.out.println("ERROR. El n�mero debe ser de dos cifras.\n");
                }
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Pongo el resultado inicialmente a la cadena vac�a
            numeroPalabra = "";
            
            // Obtenemos la primera cifra
            c1 = numero / 10;
            c2 = numero % 10;
            
            
            switch (c1) {
                case 0:
                    cifraPalabra = "cero";
                    break;
                case 1:
                    cifraPalabra = "uno";
                    break;
                case 2:
                    cifraPalabra = "dos";
                    break;
                case 3:
                    cifraPalabra = "tres";
                    break;
                case 4:
                    cifraPalabra = "cuatro";
                    break;
                case 5:
                    cifraPalabra = "cinco";
                    break;
                case 6:
                    cifraPalabra = "seis";
                    break;
                case 7:
                    cifraPalabra = "siete";
                    break;
                case 8:
                    cifraPalabra = "ocho";
                    break;
                case 9:
                    cifraPalabra = "nueve";
                    break;
                default:
                    cifraPalabra = "ERROR";
            }

            // A�adimos al resultado final la palabra de la primera cifra
            numeroPalabra += cifraPalabra + " ";

            
            switch (c2) {
                case 0:
                    cifraPalabra = "cero";
                    break;
                case 1:
                    cifraPalabra = "uno";
                    break;
                case 2:
                    cifraPalabra = "dos";
                    break;
                case 3:
                    cifraPalabra = "tres";
                    break;
                case 4:
                    cifraPalabra = "cuatro";
                    break;
                case 5:
                    cifraPalabra = "cinco";
                    break;
                case 6:
                    cifraPalabra = "seis";
                    break;
                case 7:
                    cifraPalabra = "siete";
                    break;
                case 8:
                    cifraPalabra = "ocho";
                    break;
                case 9:
                    cifraPalabra = "nueve";
                    break;
                default:
                    cifraPalabra = "ERROR";
            }

            // A�adimos al resultado final la palabra de la segunda cifra
            numeroPalabra += cifraPalabra + " ";            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d descrito en texto es \"%s\".\n",
                    numero, numeroPalabra);


        
	}
    
}