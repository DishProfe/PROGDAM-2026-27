
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CifraAPalabra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int cifra;


            // Variables de salida
            String cifraPalabra;


            // Variables auxiliares
            boolean entradaValida;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TRANSFORMACI�N DE CIFRA A PALABRA");
            System.out.println("---------------------------------");
            
            do {
                System.out.println("Introduzca una cifra (0-9)");
                cifra = teclado.nextInt();
                entradaValida = cifra>=0 && cifra<=9;
                if ( !entradaValida ) {
                    System.out.println("ERROR. El n�mero debe ser de una cifra.\n");
                }
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            switch (cifra) {
                case 0:
                    cifraPalabra = "cero";
                    break;
                case 1:
                    cifraPalabra = "uno";
                    break;
                case 2:
                    cifraPalabra = "dos";
                    break;
                case 3:
                    cifraPalabra = "tres";
                    break;
                case 4:
                    cifraPalabra = "cuatro";
                    break;
                case 5:
                    cifraPalabra = "cinco";
                    break;
                case 6:
                    cifraPalabra = "seis";
                    break;
                case 7:
                    cifraPalabra = "siete";
                    break;
                case 8:
                    cifraPalabra = "ocho";
                    break;
                case 9:
                    cifraPalabra = "nueve";
                    break;
                default:
                    cifraPalabra = "ERROR";
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("La cifra %d escrita en texto es %s.\n",
                    cifra, cifraPalabra);


        
	}
    
}