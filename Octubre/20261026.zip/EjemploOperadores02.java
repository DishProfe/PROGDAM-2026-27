
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemploOperadores02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("1.5.2.EJEMPLOS DE FORMATOS CON PRINTF");
            System.out.println("-------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            int a = 34;
            int b = 21;
            int c = a++ + ++b;   // c= 34 + 22 = 56, a=35, b=22
            int d = --a + --b + c--;     // d= 34 + 21 + 56 = 111, a=34, b=21, c=55
            int e = a + +b + +c + d--;   // e= 34 + 21 + 55 + 111 = 221 , a=34, b=21, c=55, d=110
            int f = -a + b-- + -c - d++;  // f= -34 + 21 - 55 - 110 = -178, a=34, b=20, d=111
            int sum = a + b + c + d + e + f;  // sum= 34 + 20 + 55 + 111 + 221 - 178 = 263 
            System.out.printf ("a= %4d, b= %4d, c= %4d\n", a, b, c);
            System.out.printf ("d= %4d, e= %4d, f= %4d\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %+4d, b= %+4d, c= %+4d\n", a, b, c);
            System.out.printf ("d= %+4d, e= %+4d, f= %+4d\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %04d, b= %04d, c= %04d\n", a, b, c);
            System.out.printf ("d= %04d, e= %04d, f= %04d\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %-4d, b= %-4d, c= %-4d\n", a, b, c);
            System.out.printf ("d= %-4d, e= %-4d, f= %-4d\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %8x, b= %8x, c= %8x\n", a, b, c);
            System.out.printf ("d= %8x, e= %8x, f= %8x\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %08x, b= %08x, c= %08x\n", a, b, c);
            System.out.printf ("d= %08x, e= %08x, f= %08x\n", d, e, f);
            System.out.println ();
            System.out.printf ("a= %08X, b= %08X, c= %08X\n", a, b, c);
            System.out.printf ("d= %08X, e= %08X, f= %08X\n", d, e, f);
            System.out.println ();
//            System.out.printf ("a= %-4d, b= %-4d, c= %-4d\n", a, b, c);
//            System.out.printf ("d= %-4d, e= %-4d, f= %-4d\n", d, e, f);
//            System.out.println ();
            System.out.printf ("sum = %d \n", sum);

        
	}
    
}