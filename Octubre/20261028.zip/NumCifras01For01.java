
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class NumCifras01For01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;



            // Variables de salida
            int numCifras;


            // Variables auxiliares
            long residuo;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE CIFRAS");
            System.out.println("----------------------------");
            System.out.println("Introduzca un n�mero positivo: ");
            numero = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
//            // Info de depuraci�n
//            System.out.printf ("Residuo: %15d  Numcifras: %d\n",
//                    residuo, numCifras);

/*            // Mientras el residuo no sea cero
            while ( residuo != 0 ) {
                // Tenemos una cifra
                numCifras++;
                // Calculamos el nuevo residuo 
                residuo = residuo / 10; 
                
//                // Info de depuraci�n
//                System.out.printf ("Residuo: %15d  Numcifras: %d\n",
//                        residuo, numCifras);
                
            }
*/            


            // Inicializamos el residuo que va quedando de dividir entre 10
            // El valor inicial ser� el propio n�mero
            residuo = numero;


            for ( numCifras = 0 ; residuo != 0 ; numCifras++ ) {
                residuo = residuo / 10;                 

                // Info de depuraci�n
                System.out.printf ("Residuo: %15d  Numcifras: %d\n",
                        residuo, numCifras);

            }
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero de cifras de %d es %d.\n",
                    numero, numCifras);

        
	}
    
}