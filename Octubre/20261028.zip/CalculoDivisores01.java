
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CalculoDivisores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;


            // Variables de salida



            // Variables auxiliares
            long posibleDivisor;
            boolean entradaValida;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE LOS DIVISORES DE UN N�MERO");
            System.out.println("-------------------------------------");

            do {
                System.out.println("Introduzca n�mero entero positivo: ");
                numero = teclado.nextLong();
                entradaValida = numero > 0;
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //                       +
            //              Salida de resultados 
            //----------------------------------------------

            
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Divisores de %d: \n", numero);

            // Primer valor del contador
            posibleDivisor = 2;

            do {
                // Comprobamos si numero es divisible entre posibleDivisor
                if ( numero % posibleDivisor == 0  ) {
                    // Hemos encontrado un divisor
                    System.out.printf ("%2d\n", posibleDivisor);
                }
                // Incrementamos el contador para la pr�xima prueba
                posibleDivisor++;
            } while ( posibleDivisor < numero ); // Nos salimos cuando lleguemos al n�mero





        
	}
    
}