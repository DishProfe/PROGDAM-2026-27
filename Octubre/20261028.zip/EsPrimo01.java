
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EsPrimo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;


            // Variables de salida
            boolean esPrimo;
            
            // Variables auxiliares
            long posibleDivisor;
            boolean entradaValida;
            int numDivisores;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO SI UN N�MERO ES PRIMO");
            System.out.println("-----------------------------");

            do {
                System.out.println("Introduzca n�mero entero positivo: ");
                numero = teclado.nextLong();
                entradaValida = numero > 0;
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Primer valor del contador
            posibleDivisor = 2;

            numDivisores = 0;
            do {
                // Comprobamos si numero es divisible entre posibleDivisor
                if ( numero % posibleDivisor == 0  ) {
                    // Hemos encontrado un divisor
                    numDivisores++;
                }
                // Incrementamos el contador para la pr�xima prueba
                posibleDivisor++;
            } while ( posibleDivisor <= numero / 2 ); // Nos salimos cuando superemos la mitad del n�mero

            esPrimo = numDivisores == 0;
            

            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d es primo: %b\n", numero, esPrimo);

        
	}
    
}