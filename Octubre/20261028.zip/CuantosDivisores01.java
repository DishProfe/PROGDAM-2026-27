
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CuantosDivisores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;


            // Variables de salida
            int numDivisores;


            // Variables auxiliares
            long posibleDivisor;
            boolean entradaValida;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE LOS DIVISORES DE UN N�MERO");
            System.out.println("-------------------------------------");

            do {
                System.out.println("Introduzca n�mero entero positivo: ");
                numero = teclado.nextLong();
                entradaValida = numero > 0;
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Primer valor del contador
            posibleDivisor = 2;

            // Iniciamos contador de divisores encontrados
            numDivisores = 0;
            
            do {
                // Comprobamos si numero es divisible entre posibleDivisor
                if ( numero % posibleDivisor == 0  ) {
                    // Hemos encontrado un divisor
                    numDivisores++;
                }
                // Incrementamos el contador para la pr�xima prueba
                posibleDivisor++;
            } while ( posibleDivisor <= numero / 2 ); // Nos salimos cuando superemos la mitad del n�mero


            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d tiene %d divisores.\n", numero, numDivisores);

        
	}
    
}