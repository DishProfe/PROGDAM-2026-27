
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Acumulador03For01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int inicio, fin;



            // Variables de salida
            int suma;
            int producto;
            String listaNumeros;
            boolean entradaValida;


            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ACUMULADORES");
            System.out.println("------------");
            do {
                System.out.println("Introduzca l�mite inferior: ");
                inicio = teclado.nextInt();
                System.out.println("Introduzca l�mite superior: ");
                fin = teclado.nextInt();
                entradaValida =  inicio < fin;
                if ( !entradaValida ) {
                    System.out.println("ERROR. L�mite inferior debe de estar por debajo del superior");
                }               
            } while ( !entradaValida  );


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            

            suma = 0;
            producto = 1;
            listaNumeros = "";
            
/*            contador = inicio;
            do {
                contador++;
            } while ( contador <= fin); 
*/ 

            // Valores iniciales de los acumuladores
            suma = 0;
            producto = 1;
            listaNumeros = "";
            
            // Bucle de c�lculos
            for (  contador = inicio  ; contador <= fin ; contador++ ) {
                suma = suma + contador;
                producto = producto * contador;
                listaNumeros = listaNumeros + contador + " ";                
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Suma desde %d hasta %d: %d\n",
                    inicio, fin, suma);
            System.out.printf ("Producto desde %d hasta %d: %d\n",
                    inicio, fin, producto);
            System.out.printf ("Lista desde %d hasta %d: %s\n",
                    inicio, fin, listaNumeros);
	}
    
}