
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Acumulador01For {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int suma;
            int producto;



            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ACUMULADORES");
            System.out.println("------------");
            System.out.println("Introduzca n�mero entero positivo: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            
/*
            contador = 1;
            do {
                suma = suma + contador;
                producto = producto * contador;
                contador++;
            } while ( contador <= numero); 
*/

            // Inicializaci�n de acumuladores
            suma = 0;  // Acumulador aditivo (sumas y restas)
            producto = 1;  // Acumulador multiplicativo (productos y divisones)

            // Bucle desde 1 hasta numero, ambos incluidos
            for ( contador = 1 ; contador <= numero ; contador++  ) {
                suma = suma + contador;  // Vamos sumando
                producto = producto * contador; // Vamos multiplicando               
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Suma desde 1 hasta %d: %d\n",
                    numero, suma);
            System.out.printf ("Producto desde 1 hasta %d: %d\n",
                    numero, producto);

        
	}
    
}