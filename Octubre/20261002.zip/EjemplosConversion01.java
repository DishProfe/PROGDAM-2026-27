
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemplosConversion01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int i1, i2, i3, i4, i5;
            long l1, l2, l3, l4, l5;
            float f1, f2, f3, f4, f5;
            double d1, d2, d3, d4, d5;
            char c1, c2, c3;
            byte b1, b2, b3;
            short s1, s2, s3;
            boolean logico1, logico2, logico3;
            String texto1, texto2, texto3;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE CONVERSI�N DE TIPOS");
            System.out.println("-------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            i1 = (int) 2_000_000_000L;  // Comentario 
            i2 = (int) 2_300_000_000L;

            l1 = 2_000_000_000;
            l2 = 2_300_000_000L;

            i3 =2_100_000_000;
            i3 += 1_000_000_000;
            
            i3 = (int) 3L;
            
            d1 = 2.77;
            f1 = 2.77f;
            d2 = 2.89f;
            d3 = i1;
            d4 = l1;
            l4 = (int) d1;  // Una conversi�n expl�cita a int y luego una impl�cita a long. No tiene mucho sentido.
            l4 = (long) f1;
            
            texto1 = "Hola";
            texto1 = texto1 + " " + l2;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("l1=%d\n",l1);
            System.out.printf ("l2=%d\n",l2);
            System.out.println ();

            System.out.printf ("i1=%d\n",i1);
            System.out.printf ("i2=%d\n",i2);
            System.out.println ();

            System.out.printf ("i3=%d\n",i3);
        
            System.out.printf ("texto1=%s\n",texto1);
	}
    
}