
package ejemplos;

/**
 * Programa PER�METRO Y SUPERFICIE DE RECT�NGULO
 * @author diosdado
 */

import java.util.Scanner;


public class Rectangulos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int base, altura;


            // Variables de salida
            int perimetro, superficie;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PER�METRO Y SUPERFICIE DE RECT�NGULO");
            System.out.println("------------------------------------");
            System.out.print ("Introduzca base: ");
            base = teclado.nextInt();
            System.out.print ("Introduzca altura: ");
            altura = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            superficie = base * altura;
            perimetro = 2*base + 2*altura;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Superfice del rect�ngulo: " + superficie);
            System.out.println ("Per�metro del rect�ngulo: " + perimetro);
        
	}
    
}