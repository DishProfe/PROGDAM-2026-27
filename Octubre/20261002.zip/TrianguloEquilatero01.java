
package ejemplos;

/**
 * Programa TRI�NGULO EQUILATERO
 * @author diosdado
 */

import java.util.Scanner;


public class TrianguloEquilatero01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double lado;


            // Variables de salida
            double perimetro, superficie;


            // Variables auxiliares
            double altura;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TRI�NGULO EQUILATERO");
            System.out.println("--------------------");
            System.out.print("Introduzca lado del tri�ngulo (en metros): ");
            lado = teclado.nextDouble();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            perimetro = 3 * lado;

            altura =  Math.sqrt ( lado*lado - (lado/2)*(lado/2) ) ;
            
            superficie = lado * altura / 2.0;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Per�metro: %.2f metros\n", perimetro);
            System.out.printf ("Superficie: %.2f metros cuadrados\n", superficie);

        
	}
    
}