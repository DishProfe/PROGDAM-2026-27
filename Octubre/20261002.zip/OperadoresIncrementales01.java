
package ejemplos;

/**
 * Programa EJEMPLOS DE USO DE OPERADORES INCREMENTALES
 * @author diosdado
 */

import java.util.Scanner;


public class OperadoresIncrementales01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int var1, var2, var3, var4, var5;

            int num1, num2, num3, num4, num5;

            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OPERADORES INCREMENTALES");
            System.out.println("-------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            var1 = 10;
            var1 = var1 + 1;  // Tomamos el valor de var1, le sumamos 1 y lo guardamos en var1
            var1 += 1; // Incrementamos en 1 el contenido de var1
            
            
            var2 = 100;
            var2 = var2 + 50;  // Tomamos el valor de var2, le sumamos 50 y lo guardamos en var2
            var2 += 50;  // Incrementamos en 50 el contenido de var2
            
            var3 = 1;  
            var3 = var3 + 1;  // Tomamos el valor de var3, le sumamos 1 y lo guardamos en var3
            var3 += 1;  // Incrementamos en 1 el valor de var3
            var3++;  // Incrementamos en 1 el valor de var3
            
            var4 = 10;
            var4--;
            --var4;
            --var4;
            
            num1 = 1;
            num2 = 2;
            num3 = num1++ * ++num2;  // num3 = 1 * 3 = 3, num1=2, num2=3
            num4 = ++num1 * num2++;  // num4 = 3 * 3 = 9, num1=3, num2=4 

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.printf ("var1=%d\n", var1);
            System.out.printf ("var2=%d\n", var2);
            System.out.printf ("var3=%d\n", var3);
            System.out.printf ("var4=%d\n", var4);
            System.out.println ();
            System.out.printf ("num3=%d\n", num3);
            System.out.printf ("num4=%d\n", num4);
        
	}
    
}