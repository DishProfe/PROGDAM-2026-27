
package ejemplos;

/**
 * Programa PER�METRO Y SUPERFICIE DE RECT�NGULO
 * @author diosdado
 */

import java.util.Scanner;


public class Rectangulos04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double base, altura;


            // Variables de salida
            double perimetroMetros, perimetroCm, perimetroDm;
            double superficieMetros, superficieCm, superficieDm;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PER�METRO Y SUPERFICIE DE RECT�NGULO");
            System.out.println("------------------------------------");
            System.out.print ("Introduzca base: ");
            base = teclado.nextDouble();
            System.out.print ("Introduzca altura: ");
            altura = teclado.nextDouble();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            superficieMetros = base * altura;
            perimetroMetros = 2*base + 2*altura;

            superficieDm = superficieMetros * 100;
            superficieCm = superficieMetros * 10000;
            
            perimetroDm = perimetroMetros * 10;
            perimetroCm = perimetroMetros * 100;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.println ("Superfice del rect�ngulo (metros): " + superficieMetros);
            System.out.println ("Per�metro del rect�ngulo: " + perimetroMetros + " metros");
            System.out.println();

            System.out.printf ("Superfice del rect�ngulo: %.2f dec�metros cuadrados\n", superficieDm);
            System.out.printf ("Per�metro del rect�ngulo (en dec�metros): %.2f\n", superficieDm);
            System.out.println();
            
            System.out.printf ("Superfice del rect�ngulo: %.2f cent�metros cuadrados\n", superficieCm);
            System.out.println("Per�metro del rect�ngulo: " + perimetroCm + " cent�metros");
            
	}
    
}