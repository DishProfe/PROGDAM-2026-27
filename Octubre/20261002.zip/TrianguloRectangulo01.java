
package ejemplos;

/**
 * Programa XXX
 * @author TRI�NGULO RECT�NGULO
 */

import java.util.Scanner;


public class TrianguloRectangulo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double base, altura;


            // Variables de salida
            double perimetro;
            double superficie;


            // Variables auxiliares
            double hipotenusa;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TRI�NGULO RECT�NGULO");
            System.out.println("--------------------");

            System.out.print("Introduzca base (en m): ");
            base = teclado.nextDouble();
            
            System.out.print("Introduzca altura (en m): ");
            altura = teclado.nextDouble();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            hipotenusa  = Math.sqrt(base*base + altura*altura);

            superficie = base*altura/2.0;
            perimetro = base + altura + hipotenusa;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Superficie: " + superficie + " metros cuadrados");
            System.out.println ("Per�metro: " + perimetro + " metros");

            System.out.printf ("Superficie: %.2f metros cuadrados\n", superficie);
            System.out.printf ("Per�metro: %.2f metros\n", perimetro);
            
        
	}
    
}