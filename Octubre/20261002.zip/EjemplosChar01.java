
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemplosChar01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            char c1 = 'S';
            char c2 = 'F';
            char c3 = 65;
            char c4 = 0b01000001;
            char c5 = 0b00110001;
            char c6 = 50;
            char c7 = 97;
            char c8 = 'b';
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE CHAR");
            System.out.println("----------------");
            System.out.println("");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("c1 = " + c1);
            System.out.println("c2 = " + c2);
            System.out.println("c3 = " + c3);
            System.out.println("c4 = " + c4);
            System.out.println("c5 = " + c5);
            System.out.println("c6 = " + c6);
            System.out.println("c7 = " + c7);
            System.out.println("c8 = " + c8);

        
	}
    
}