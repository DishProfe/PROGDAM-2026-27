
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EscribeNumeros03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int inicio;
            int fin;



            // Variables de salida



            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA QUE MUESTRA N�MEROS");
            System.out.println("----------------------------");
            
            System.out.println("Introduzca l�mite inferior: ");
            inicio = teclado.nextInt();
            System.out.println("Introduzca l�mite superior: ");
            fin = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            contador = inicio;
            do {
                System.out.println (contador);
                contador++;
            } while ( contador <= fin );

            
          

        
	}
    
}