
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Acumulador01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int suma;
            int producto;



            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ACUMULADORES");
            System.out.println("------------");
            System.out.println("Introduzca n�mero entero positivo: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            contador = 1;
            suma = 0;
            producto = 1;
            
            do {
                suma = suma + contador;
                producto = producto * contador;
                contador++;
            } while ( contador <= numero); 



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Suma desde 1 hasta %d: %d\n",
                    numero, suma);
            System.out.printf ("Producto desde 1 hasta %d: %d\n",
                    numero, producto);

        
	}
    
}