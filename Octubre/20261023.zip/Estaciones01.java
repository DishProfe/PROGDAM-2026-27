
package ejemplos2026;

/**
 * Programa MESES EN UNA ESTACI�N
 * @author diosdado
 */

import java.util.Scanner;


public class Estaciones01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String estacion;



            // Variables de salida
            String meses; 


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MESES EN UNA ESTACI�N");
            System.out.println("---------------------");
            System.out.println("Introduzca nombre de estaci�n del a�o: ");

            estacion = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( estacion.equals ("primavera")  )  {
                meses = "marzo, abril, mayo, junio";
            } else if ( estacion.equals ("verano") ) {
                meses = "junio, julio, agosto, septiembre";                    
            } else if ( estacion.equals ("oto�o") ) {
                meses = "septiembre, octubre, noviembre, diciembre";                    
            } else if ( estacion.equals ("invierno") ) {
                meses = "diciembre, enero, febrero, marzo";                                    
            } else {
                meses = "ERROR: no es una estaci�n v�lida";
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Los meses de la estaci�n %s son:\n",
                    estacion);
            System.out.println (meses);

        
	}
    
}