
package ejemplos2026;

/**
 * Programa MESES EN UNA ESTACI�N
 * @author diosdado
 */

import java.util.Scanner;


public class Estaciones03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String estacion;



            // Variables de salida
            String meses; 


            // Variables auxiliares
            String estacionMinusculas;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MESES EN UNA ESTACI�N");
            System.out.println("---------------------");
            System.out.println("Introduzca nombre de estaci�n del a�o: ");

            estacion = teclado.nextLine();
            estacionMinusculas = estacion.toLowerCase(); 

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( estacionMinusculas.equals ("primavera")  )  {
                meses = "marzo, abril, mayo, junio";
            } else if ( estacionMinusculas.equals ("verano") ) {
                meses = "junio, julio, agosto, septiembre";                    
            } else if ( estacionMinusculas.equals ("oto�o") ) {
                meses = "septiembre, octubre, noviembre, diciembre";                    
            } else if ( estacionMinusculas.equals ("invierno") ) {
                meses = "diciembre, enero, febrero, marzo";                                    
            } else {
                meses = "ERROR: no es una estaci�n v�lida";
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Los meses de la estaci�n %s son:\n",
                    estacionMinusculas);
            System.out.println (meses);

        
	}
    
}