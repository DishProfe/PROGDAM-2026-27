
package ejemplos2026;

/**
 * Programa MESES EN UNA ESTACI�N
 * @author diosdado
 */

import java.util.Scanner;


public class Estaciones04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String estacion;



            // Variables de salida
            String meses; 


            // Variables auxiliares
            String estacionMinusculas;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MESES EN UNA ESTACI�N");
            System.out.println("---------------------");
            System.out.println("Introduzca nombre de estaci�n del a�o: ");

            estacion = teclado.nextLine();
            estacionMinusculas = estacion.toLowerCase(); 

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            switch ( estacionMinusculas ) {
                
                case "primavera":
                    meses = "marzo, abril, mayo, junio";   
                    break;
                    
                case "verano":
                    meses = "junio, julio, agosto, septiembre";
                    break;

                case "oto�o":
                    meses = "septiembre, octubre, noviembre, diciembre"; 
                    break;
                    
                case "invierno":    
                    meses = "diciembre, enero, febrero, marzo";
                    break;
                    
                default:
                     meses = "ERROR: no es una estaci�n v�lida";
            }
            
                    
                    
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Los meses de la estaci�n %s son:\n",
                    estacionMinusculas);
            System.out.println (meses);

        
	}
    
}