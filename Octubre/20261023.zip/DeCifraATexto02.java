
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class DeCifraATexto02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int cifra;



            // Variables de salida
            String textoCifra;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DE CIFRA A TEXTO");
            System.out.println("----------------");
            System.out.println("Introduzca una cifra (0-9): ");
            cifra = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            switch ( cifra ) {
                
                case 0:
                    textoCifra = "cero";
                    break;
                    
                case 1:
                    textoCifra = "uno";                    
                    break;
    
                case 2:
                    textoCifra = "dos";                    
                    break;
                    
                case 3:
                    textoCifra = "tres";                    
                    break;
                    
                default:
                    textoCifra = "ERROR";
                
            } 
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d en formato texto es: \"%s\"\n",
                    cifra, 
                    textoCifra);

        
	}
    
}