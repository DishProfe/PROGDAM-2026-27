
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class DiasLaborables02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia;



            // Variables de salida
            String tipoDia;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("D�AS LABORABLES");
            System.out.println("---------------");
            System.out.println("Introduzca d�a de la semana (1-7): ");
            dia = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            tipoDia = dia >= 1 && dia <=5 ? "Laborable" 
                    : dia == 6 || dia == 7 ? "Festivo" 
                    : "ERROR";


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El d�a %d es: %s\n", dia, tipoDia);


        
	}
    
}