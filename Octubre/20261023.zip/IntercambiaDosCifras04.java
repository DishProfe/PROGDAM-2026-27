
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class IntercambiaDosCifras04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int numeroInverso = 0;


            // Variables auxiliares
            int c1, c2;
            boolean numeroValido;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA DE INTERCAMBIO DE CIFRAS");
            System.out.println("---------------------------------");

            do {
                System.out.print ("Introduzca un n�mero positivo de dos cifras: (10-99) ");
                numero = teclado.nextInt();
                numeroValido = numero>=10 && numero<=99;
                if ( !numeroValido ) {
                    System.out.println ("ERROR: el n�mero debe de ser positivo de dos cifras");
                }
            } while ( !numeroValido );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( numeroValido ) {
            
                // Calculo la primera cifra (decenas)
                c1 = numero / 10;

                // Calculo la segunda cifra (unidades)
                c2 = numero % 10;

                // Construyo el nuevo n�mero
                numeroInverso = c2 * 10 + c1;
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (numeroValido) {
                System.out.printf ("El n�mero con las cifras cambiadas es: %02d\n", numeroInverso);
            } else {
                System.out.println ("Error: el n�mero debe tener dos cifras");                
            }
            
        
	}
    
}