
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class DiasLaborables04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String dia;



            // Variables de salida
            String tipoDia;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("D�AS LABORABLES");
            System.out.println("---------------");
            System.out.println("Introduzca d�a de la semana (1-7): ");
            dia = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            switch ( dia ) {
                case "lunes":
                case "martes":
                case "miercoles":
                case "jueves": 
                case "viernes": 
                    tipoDia ="Laborable";
                    break;
                case "sabado":  case "domingo": 
                    tipoDia ="Festivo";
                    break;
                default:
                    tipoDia ="ERROR";
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El d�a %s es: %s\n", dia, tipoDia);


        
	}
    
}