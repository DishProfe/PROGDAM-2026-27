
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class DeCifraATexto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int cifra;



            // Variables de salida
            String textoCifra;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DE CIFRA A TEXTO");
            System.out.println("----------------");
            System.out.println("Introduzca una cifra (0-9): ");
            cifra = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( cifra == 0 ) {
                textoCifra = "cero";
            } else if ( cifra == 1 ) {
                textoCifra = "uno";                    
            } else if ( cifra == 2) {
                textoCifra = "dos";                                    
            } else if ( cifra == 3) {
                textoCifra = "tres";                                    
            } else {
                textoCifra = "ERROR";
            }
                
            
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d en formato texto es: \"%s\"\n",
                    cifra, 
                    textoCifra);

        
	}
    
}