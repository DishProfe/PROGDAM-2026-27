
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Garrafas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int litros;



            // Variables de salida
            int g1, g2, g5;


            // Variables auxiliares
            int resto;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CANTIDAD DE GARRAFAS �PTIMA");
            System.out.println("---------------------------");
            System.out.println("Introduzca cantidad de litros: ");
            litros = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            g5 = litros / 5;
            resto = litros % 5;
            
            g2 = resto / 2;
            resto = resto % 2;
            
            g1 = resto;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Para una garrafa de %d litros se necesita: \n", litros);
            System.out.printf ("%d garrafas de 5 litros\n", g5);
            System.out.printf ("%d garrafas de 2 litros\n", g2);
            System.out.printf ("%d garrafas de 1 litro\n",  g1);
        
	}
    
}