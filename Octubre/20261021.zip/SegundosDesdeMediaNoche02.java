
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class SegundosDesdeMediaNoche02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int hora, minuto, segundo;



            // Variables de salida
            int segundosDesdeMedianoche = 0;


            // Variables auxiliares
            boolean horaValida, minutoValido, segundoValido;
            boolean entradaValida;
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE");
            System.out.println("---------------------------------------");
            System.out.println("Introduzca hora, minuto, segundo");
            hora = teclado.nextInt();
            minuto = teclado.nextInt();
            segundo = teclado.nextInt();

            horaValida = hora>=0 && hora<=23;
            
            minutoValido = minuto>=0 && minuto<=59;

            segundoValido = segundo>=0 && segundo<=59;
            
            entradaValida = horaValida && minutoValido && segundoValido;
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            if ( entradaValida ) {

                segundosDesdeMedianoche = hora*3600 + minuto*60 + segundo;
                
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( entradaValida ) {
                System.out.printf ("Han transcurrido %d segundos desde medianoche\n", 
                    segundosDesdeMedianoche);
            } else {
                System.out.println ("Error: la hora no es v�lida");                
            }

        
	}
    
}