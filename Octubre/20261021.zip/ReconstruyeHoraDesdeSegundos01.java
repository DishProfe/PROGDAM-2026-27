
package ejemplos2026;

/**
 * Programa RECONSTRUYE HORA A PARTIR DEL N�MERO DE SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE
 * @author diosdado
 */

import java.util.Scanner;


public class ReconstruyeHoraDesdeSegundos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int segundosDesdeMedianoche;



            // Variables de salida
            int hora, minuto, segundo;


            // Variables auxiliares
            int resto;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("RECONSTRUYE HORA A PARTIR DEL N�MERO DE SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE");
            System.out.println("---------------------");
            System.out.println("Introduzca segundos transcurridos desde medianoche: ");
            segundosDesdeMedianoche = teclado.nextInt();

            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            hora = segundosDesdeMedianoche / 3600;
            resto = segundosDesdeMedianoche % 3600;

            minuto = resto / 60;
            segundo = resto % 60;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            //System.out.println (hora + ":" + minuto + ":" + segundo);
            System.out.printf ("%02d:%02d:%02d\n", hora, minuto, segundo);

        
	}
    
}