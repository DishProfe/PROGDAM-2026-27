
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class IntercambiaTresCifras02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int numeroInverso = 0;


            // Variables auxiliares
            int c1, c2, c3;
            boolean numeroValido;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA DE INTERCAMBIO DE CIFRAS");
            System.out.println("---------------------------------");
            System.out.print ("Introduzca un n�mero de tres cifras: ");
            numero = teclado.nextInt();

            numeroValido = numero>=100 && numero<=999;
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( numeroValido ) {
                // Calculo la primera cifra (centenas)
                c1 = numero / 100;

                // Calculo la segunda cifra (decenas)
                c2 = (numero % 100) / 10;

                // Calculo la tercera cifra (unidades)
                c3 = numero % 10;

                // Construyo el nuevo n�mero

                numeroInverso = c3*100 + c2*10 + c1;
            }
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (numeroValido) {
                System.out.printf ("El n�mero con las cifras cambiadas es: %03d\n", numeroInverso);
            } else {
                System.out.println ("Error: el n�mero debe tener tres cifras");                
            }

        
	}
    
}