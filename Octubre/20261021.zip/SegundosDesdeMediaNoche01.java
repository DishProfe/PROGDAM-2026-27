
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class SegundosDesdeMediaNoche01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int hora, minuto, segundo;



            // Variables de salida
            int segundosDesdeMedianoche;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE");
            System.out.println("---------------------------------------");
            System.out.println("Introduzca hora, minuto, segundo");
            hora = teclado.nextInt();
            minuto = teclado.nextInt();
            segundo = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            segundosDesdeMedianoche = hora*3600 + minuto*60 + segundo;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Han transcurrido %d segundos desde medianoche\n", 
                    segundosDesdeMedianoche);


        
	}
    
}