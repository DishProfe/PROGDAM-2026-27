
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class IntercambiaDosCifras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int numeroInverso;


            // Variables auxiliares
            int c1, c2;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA DE INTERCAMBIO DE CIFRAS");
            System.out.println("---------------------------------");
            System.out.print ("Introduzca un n�mero de dos cifras: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Calculo la primera cifra (decenas)
            c1 = numero / 10;
            
            // Calculo la segunda cifra (unidades)
            c2 = numero % 10;

            // Construyo el nuevo n�mero
            numeroInverso = c2 * 10 + c1;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero con las cifras cambiadas es: %d\n", numeroInverso);

        
	}
    
}