
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CalculaDiasMes01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes, year;



            // Variables de salida
            int numDias;


            // Variables auxiliares
            boolean tiene30, tiene31;
            boolean esBisiesto;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE D�AS DE UN MES");
            System.out.println("------------------------------------");
            System.out.println("Introduzca mes y a�o:");

            mes = teclado.nextInt();
            year = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            tiene30 = mes == 4 || mes == 6 || mes == 9 || mes == 11;
            tiene31 = !tiene30 && mes != 2;
            
            esBisiesto =  (year % 4 == 0 && year % 100 != 0) || year % 400 == 0 ;
            
            numDias = tiene30 ? 30 
                    : tiene31 ? 31
                    : esBisiesto ? 29 : 28;
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El mes %d del a�o %d tiene %d d�as.\n",
                    mes, year, numDias);
            

        
	}
    
}