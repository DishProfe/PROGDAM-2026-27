
package ejemplos2026;

/**
 * Programa C�LCULO DEL N�MERO DE D�AS DE UN MES
 * @author diosdado
 */

import java.util.Scanner;


public class CalculaDiasMes02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes, year;



            // Variables de salida
            int numDias;


            // Variables auxiliares
            boolean tiene30, tiene31;
            boolean esBisiesto;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE D�AS DE UN MES");
            System.out.println("------------------------------------");
            System.out.println("Introduzca mes y a�o:");

            mes = teclado.nextInt();
            year = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if ( mes == 4 || mes == 6 || mes == 9 || mes == 11 ) {
                tiene30 = true;
            } else {
                tiene30 = false;
            }
            
            if ( !tiene30 && mes != 2 ) {
                tiene31 = true;
            } else {
                tiene31 = false;                
            }

            if ( ( year % 4 == 0 && year % 100 != 0) || year % 400 == 0  ) {
                esBisiesto = true;
            } else {
                esBisiesto = false;                    
            }

            if ( tiene30 ) {
                numDias = 30;
            } else if ( tiene31 ) {
                numDias = 31;
            } else if ( esBisiesto ) {
                numDias = 29;
            } else {
                numDias = 28;
            }
            
            
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El mes %d del a�o %d tiene %d d�as.\n",
                    mes, year, numDias);
            

        
	}
    
}