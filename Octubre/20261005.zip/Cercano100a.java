
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Cercano100a {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero1, numero2;


            // Variables de salida
            int masCercano100;


            // Variables auxiliares
            int distancia1, distancia2;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO M�S CERCANO A 100");
            System.out.println("------------------------------------");

            System.out.println("Introduzca primer n�mero: ");
            numero1 = teclado.nextInt();

            System.out.println("Introduzca segundo n�mero: ");
            numero2 = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            distancia1 = 100 - numero1;
            distancia2 = 100 - numero2;

            masCercano100 = distancia1 < distancia2 ? numero1 : numero2 ; 

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Distancia de %d a 100: %d\n", numero1, distancia1);
            System.out.printf ("Distancia de %d a 100: %d\n", numero2, distancia2);
            System.out.printf ("El n�mero m�s cercano a 100 es %d\n", masCercano100);

        
	}
    
}