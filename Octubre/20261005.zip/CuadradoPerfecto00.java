
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CuadradoPerfecto00 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int numero;

            // Variables de salida
            boolean esCuadradoPerfecto;

            // Variables auxiliares
            double raizReal;
            int raizEntera;
            int cuadrado;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CUADRADO PERFECTO");
            System.out.println("---------------------------------");
            System.out.print("Introduzca n�mero entero: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            raizReal =  Math.sqrt (numero);
            raizEntera = (int) raizReal;
            cuadrado = raizEntera * raizEntera;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Ra�z real: %.3f\n", raizReal);
            System.out.printf ("Ra�z entera: %d\n", raizEntera);
            System.out.printf ("Producto: %d\n", cuadrado);
            //System.out.printf ("El n�mero %d es un cuadrado perfecto: %b\n", esCuadradoPerfecto);

        
	}
    
}