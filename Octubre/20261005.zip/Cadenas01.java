
package ejemplos;

/**
 * Programa EJEMPLOS CON CADENAS
 * @author diosdado
 */

import java.util.Scanner;


public class Cadenas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            
            // Cadenas de ejemplo con las que trabajar
            String cadena1 = "CICLO DAM-DAW";
            String cadena2 = "ciclo dam-daw";

            String texto1, texto2, texto3, texto4, texto5;
            String texto6, texto7, texto8, texto9;


            // Variables de salida
            int longCadena1, longCadena2;
            String cadena3, cadena4;
            String cadena5, cadena6;
            boolean cadenasIguales1, cadenasIguales2;
            boolean cadenasIgualesNoCase;
            String subcadena1, subcadena2;
            String aMay1, aMay2, aMin1, aMin2;
            char primerChar1, primerChar2, ultimoChar1, ultimoChar2;
            
            
            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS CON CADENAS");
            System.out.println("--------------------");
            System.out.println();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtenci�n de longitudes (cantidad de caracteres en las cadenas)
            longCadena1 = cadena1.length();
            longCadena2 = cadena2.length();

            // Concatenaciones
            cadena3 = cadena1 + cadena2; // cadena1.concat(cadena2)
            cadena4 = cadena2.concat (cadena1); // cadena2 + cadena1

            cadena5 = cadena1 + "   " + cadena2;
            cadena6 = cadena2.concat("   ").concat(cadena1);

            // Comparaciones
            cadenasIguales1 =  cadena1.equals(cadena2);
            cadenasIguales2 =  cadena2.equals(cadena1);
            cadenasIgualesNoCase = cadena1.equalsIgnoreCase(cadena2);
                    
            // Obtenci�n de subcadenas
            subcadena1 = cadena1.substring(0, 5);
            subcadena2 = cadena2.substring(6);
            
            // Paso a may�sculas o a min�sculas
            aMay1 = cadena1.toUpperCase();
            aMay2 = cadena2.toUpperCase();
            aMin1 = cadena1.toLowerCase();
            aMin2 = cadena2.toLowerCase();
            
            // Obtenci�n del primer y �ltimo car�cter de una cadena
            primerChar1 = cadena1.charAt(0);
            primerChar2 = cadena2.charAt(0);
            ultimoChar1 = cadena1.charAt(longCadena1-1);
            ultimoChar2 = cadena2.charAt(longCadena2-1);
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos las cadenas originales
            System.out.println ("La cadena cadena1 es: \"" + cadena1 + "\"");
            System.out.printf  ("La cadena cadena2 es: \"%s\"\n", cadena2);
            System.out.println ();

            System.out.println ("La longitud de cadena 1 es: " + longCadena1);
            System.out.printf  ("La longitud de cadena 2 es: %d\n", longCadena2);
            System.out.println ();

            System.out.println ("Concatenaci�n de cadena1 y cadena2: \"" + cadena3 + "\"");            
            System.out.printf  ("Concatenaci�n de cadena2 y cadena1: \"%s\"\n", cadena4);            
            System.out.printf  ("Concatenaciones de m�s de dos cadenas:\n");            
            System.out.println ("\"" + cadena5 + "\"");            
            System.out.printf  ("\"%s\"\n", cadena6);        
            
            System.out.println ();
            System.out.println("cadena1 es igual a cadena2: " + cadenasIguales1);
            System.out.printf ("cadena1 es igual a cadena2: %b\n", cadenasIguales2);
            System.out.println("cadena1 es igual a cadena2: " + (cadenasIguales1 ? "S�" : "No") );
            System.out.printf ("cadena1 es igual a cadena2: %s\n", cadenasIguales1 ? "S�" : "No");
            System.out.println("cadena1 es igual a cadena2 sin tener en cuenta may�sculas: " + cadenasIgualesNoCase);
            System.out.printf ("cadena1 es igual a cadena2 sin tener en cuenta may�sculas: %s\n", cadenasIgualesNoCase ? "S�" : "No");
            System.out.println ();

            System.out.println ("Subcadena de cadena1 desde 0, 5 elementos: \"" + subcadena1 + "\"");
            System.out.printf  ("Subcadena de cadena2 desde 5 hasta el final: \"%s\"\n", subcadena2);
            System.out.println ();

            System.out.println ("Paso a may�sculas: ");
            System.out.printf ("\"%s\"\n", aMay1);
            System.out.printf ("\"%s\"\n", aMay2);
            System.out.println ();

            System.out.println ("Paso a min�sculas: ");
            System.out.printf ("\"%s\"\n", aMin1);
            System.out.printf ("\"%s\"\n", aMin2);
            System.out.println ();

            System.out.printf("Primer caracter de cadena1: '%c'\n", primerChar1);
            System.out.printf("�ltimo caracter de cadena1: '%c'\n", ultimoChar1);
            System.out.printf("Primer caracter de cadena2: '%c'\n", primerChar2);
            System.out.printf("�ltimo caracter de cadena2: '%c'\n", ultimoChar2);
            
            System.out.println ();

            
	}
    
}