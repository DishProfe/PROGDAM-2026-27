
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CuadradoPerfecto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esCuadradoPerfecto;


            // Variables auxiliares
            double raizReal;
            int raizEntera;
            int producto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CUADRADO PERFECTO");
            System.out.println("---------------------------------");
            System.out.print("Introduzca n�mero entero: ");
            numero = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Calculamos la ra�z cuadrada del n�mero
            raizReal = Math.sqrt (numero);

            // Convertimos la ra�z cuadrada a n�mero entero (conversi�n expl�cita o casting)
            raizEntera = (int) raizReal; 

            // Multiplicamos la ra�z entera por s� misma
            producto = raizEntera * raizEntera;
            
            // Comparamos esa multiplicaci�n con el n�mero inicial
            esCuadradoPerfecto =  producto == numero;
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Raiz real   = %.2f\n", raizReal);
            System.out.printf ("Raiz entera = %d\n", raizEntera);
            System.out.printf ("Producto    = %d\n", producto);
            System.out.printf ("Es cuadrado perfecto: %b\n", esCuadradoPerfecto);

            System.out.printf ("El n�mero %d %ses un cuadrado perfecto.\n",
                    numero, esCuadradoPerfecto ? "" : "no ");

        
	}
    
}