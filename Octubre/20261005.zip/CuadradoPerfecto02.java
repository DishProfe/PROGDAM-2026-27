
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class CuadradoPerfecto02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esCuadradoPerfecto;


            // Variables auxiliares
            double raizReal;
            int raizEntera;
            int producto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CUADRADO PERFECTO");
            System.out.println("---------------------------------");
            System.out.print("Introduzca n�mero entero: ");
            numero = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Comparamos el cuadrado de la parte entera de la ra�z con el n�mero inicial
            esCuadradoPerfecto = numero == ((int) Math.sqrt (numero)) * (int) Math.sqrt (numero) ;
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.printf ("El n�mero %d %ses un cuadrado perfecto.\n",
                    numero, esCuadradoPerfecto ? "" : "no ");

        
	}
    
}