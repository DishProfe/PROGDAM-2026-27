
package ejemplos;

/**
 * Programa C�LCULO DEL N�MERO M�S CERCANO A 100
 * @author diosdado
 */

import java.util.Scanner;


public class Cercano100c {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero1, numero2;


            // Variables de salida
            int masCercano100;


            // Variables auxiliares
            int distancia1, distancia2;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO M�S CERCANO A 100");
            System.out.println("------------------------------------");

            System.out.println("Introduzca primer n�mero: ");
            numero1 = teclado.nextInt();

            System.out.println("Introduzca segundo n�mero: ");
            numero2 = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            masCercano100 = Math.abs (100 - numero1) < Math.abs (100 - numero2) ? numero1 : numero2 ; 

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero m�s cercano a 100 es %d\n", masCercano100);

        
	}
    
}