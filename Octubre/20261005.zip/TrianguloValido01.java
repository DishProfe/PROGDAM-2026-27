
package ejemplos;

/**
 * Programa COMPROBACI�N DE VALIDEZ DE TRI�NGULO
 * @author diosdado
 */

import java.util.Scanner;


public class TrianguloValido01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double lado1, lado2, lado3;



            // Variables de salida
            boolean trianguloPosible;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println ("COMPROBACI�N DE VALIDEZ DE TRI�NGULO");
            System.out.println ("---------------------");
            System.out.println ("Introduzca longitud de cada uno de los tres lados:");
            lado1 = teclado.nextDouble();
            lado2 = teclado.nextDouble();
            lado3 = teclado.nextDouble();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            trianguloPosible = lado1 < lado2+lado3 && lado2 < lado1+lado3 && lado3 < lado1+lado2;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El tri�ngulo es viable: %b\n", trianguloPosible);
            System.out.printf ("El tri�ngulo %ses viable\n", trianguloPosible ? "" : "no ");

        
	}
    
}