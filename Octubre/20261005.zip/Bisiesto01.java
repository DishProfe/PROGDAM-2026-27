
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Bisiesto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int year;


            // Variables de salida
            boolean esBisiesto;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CALCULAMOS SI UN A�O ES BISIESTO");
            System.out.println("--------------------------------");
            System.out.print("Introduzca a�o: ");
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            esBisiesto = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0); 

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El a�o %d %ses bisiesto.\n",
                    year, (esBisiesto ? "" : "no ") );

        
	}
    
}