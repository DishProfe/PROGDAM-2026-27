
package ejemplolib01;

/**
 * Programa OBJETOS DE LIBAGUADULCE
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Dado;
import aguadulce.Bombilla;
import aguadulce.CuentaBancaria;


public class EjemploCuentaBancaria01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado d1, d2, d3;
            CuentaBancaria c1, c2, c3, c4;
            Bombilla b1, b2, b3;
            
            double saldo1;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OBJETOS DE LIBAGUADULCE");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            c1 = new CuentaBancaria (100.00);
            c2 = new CuentaBancaria ();
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            saldo1 = c1.getSaldo();
            System.out.printf ("Cuenta c1 - saldo: %.2f\n", c1.getSaldo() );
            System.out.printf ("Id c1: %d\n", c1.getId() );
            System.out.printf ("Fecha de creaci�n de c1: %s\n", c1.getFechaCreacion() );
            System.out.printf ("Cuenta c1 - est� embargada: %b\n", c1.isEmbargada() );
            System.out.println ();
            System.out.printf ("Cuenta c2 - saldo: %.2f\n", c2.getSaldo() );
            System.out.printf ("Id c2: %d\n", c2.getId() );
            System.out.printf ("Fecha de creaci�n de c2: %s\n", c2.getFechaCreacion() );
            System.out.println ();

            System.out.println("Ingresamos 50.00 euros en c1");
            c1.ingresar(50.00);
            System.out.printf ("Cuenta c1 - saldo: %.2f\n", c1.getSaldo() );
            System.out.printf ("Cuenta c2 - saldo: %.2f\n", c2.getSaldo() );
            System.out.println ();
            
            System.out.println("Sacamos 90.00 euros de c1");
            c1.extraer (90.00);
            System.out.printf ("Cuenta c1 - saldo: %.2f\n", c1.getSaldo() );
            System.out.printf ("Cuenta c2 - saldo: %.2f\n", c2.getSaldo() );
            System.out.println ();

            System.out.println("Transferimos 50 euros desde c1 hacia c2");
            c1.transferir (50, c2);
            System.out.printf ("Cuenta c1 - saldo: %.2f\n", c1.getSaldo() );
            System.out.printf ("Cuenta c2 - saldo: %.2f\n", c2.getSaldo() );
            System.out.println ();

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}