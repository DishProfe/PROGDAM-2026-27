
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Dado;


public class EjemploDado01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado d1, d2, d3, d4, d5;
            String lanzamiento;
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OBJETOS DE LIBAGUADULCE");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.println("Creamos un dado con los valores por omisi�n");
            d1 = new Dado ();
            System.out.printf ("d1 -> N�mero de caras: %d\n", d1.getNumeroCaras());
            System.out.printf ("d1 -> N�mero de veces lanzado: %d\n", d1.getNumeroLanzamientos() );
            System.out.println ();
            
            System.out.println("Lanzamos d1");
            lanzamiento = d1.lanzar();
            System.out.printf ("d1 resultado del lanzamiento: %s\n", lanzamiento );
            System.out.printf ("d1 -> N�mero de caras: %d\n", d1.getNumeroCaras());
            System.out.printf ("d1 -> N�mero de veces lanzado: %d\n", d1.getNumeroLanzamientos() );
            System.out.printf ("d1 -> N�mero de veces que ha salido 3: %d\n", 
                    d1.getNumeroVecesCara(3) );
            System.out.println ();
        
            System.out.println("Lanzamos d1");
            lanzamiento = d1.lanzar();
            System.out.printf ("d1 resultado del lanzamiento: %s\n", lanzamiento );
            System.out.printf ("d1 -> N�mero de caras: %d\n", d1.getNumeroCaras());
            System.out.printf ("d1 -> N�mero de veces lanzado: %d\n", d1.getNumeroLanzamientos() );
            System.out.printf ("d1 -> N�mero de veces que ha salido 3: %d\n", 
                    d1.getNumeroVecesCara(3) );
            System.out.println ();

            System.out.println("Lanzamos d1");
            lanzamiento = d1.lanzar();
            System.out.printf ("d1 resultado del lanzamiento: %s\n", lanzamiento );
            System.out.printf ("d1 -> N�mero de caras: %d\n", d1.getNumeroCaras());
            System.out.printf ("d1 -> N�mero de veces lanzado: %d\n", d1.getNumeroLanzamientos() );
            System.out.printf ("d1 -> N�mero de veces que ha salido 3: %d\n", 
                    d1.getNumeroVecesCara(3) );
            System.out.println ();
        
        }
    
}