
package ejemplolib01;

/**
 * Programa LANZANDO LOS DADOS
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class LanzarDados01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado d1;
            int numCaras;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LANZANDO LOS DADOS");
            System.out.println("------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            for ( numCaras = 0  ; numCaras<=10 ; numCaras++ ) {

                try {
                    d1 = new Dado ( numCaras );
                    System.out.printf ("Dado de %d caras creado con �xito\n", numCaras);
                } catch ( IllegalArgumentException ex ) {
                    System.out.printf("Error al intentar crear dado de %d caras\n",
                            numCaras);
                }
                
            }
            
            
            
            
            

        
        
	}
    
}