
package ejemplos2026;

/**
 * Programa OBJETOS DE LIBAGUADULCE
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Bombilla;


public class EjemploBombilla01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Bombilla b1, b2, b3, b4;
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OBJETOS DE LIBAGUADULCE");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();
            
            System.out.println("Creamos objeto Bombilla b1 con constructor sin par�metros");
            b1 = new Bombilla ();
            System.out.printf ("b1 -> estado: %b\n", b1.getEstado() );
            System.out.printf ("b1 -> est� apagada: %b\n", b1.isApagada() );
            System.out.printf ("b1 -> est� encendida: %b\n", b1.isEncendida() );
            System.out.printf ("b1 -> n�mero de veces encendida: %d\n", b1.getVecesEncendida() );
            System.out.printf ("b1 -> potencia: %.2f\n", b1.getPotencia() );
            System.out.printf ("b1 -> tiempo encendida: %.2f\n", b1.getTiempoEncendida() );
            System.out.println ();

            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();

            
            System.out.println("Encendemos b1");
            b1.encender();
            System.out.printf ("b1 -> estado: %b\n", b1.getEstado() );
            System.out.printf ("b1 -> est� apagada: %b\n", b1.isApagada() );
            System.out.printf ("b1 -> est� encendida: %b\n", b1.isEncendida() );
            System.out.printf ("b1 -> n�mero de veces encendida: %d\n", b1.getVecesEncendida() );
            System.out.printf ("b1 -> potencia: %.2f\n", b1.getPotencia() );
            System.out.printf ("b1 -> tiempo encendida: %.2f\n", b1.getTiempoEncendida() );
            System.out.println ();

            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();


            System.out.println("Creamos objeto Bombilla b2 con 100W de potencia");
            b2 = new Bombilla (100.00);
            System.out.printf ("b2 -> estado: %b\n", b2.getEstado() );
            System.out.printf ("b2 -> est� apagada: %b\n", b2.isApagada() );
            System.out.printf ("b2 -> est� encendida: %b\n", b2.isEncendida() );
            System.out.printf ("b2 -> n�mero de veces encendida: %d\n", b2.getVecesEncendida() );
            System.out.printf ("b2 -> potencia: %.2f\n", b2.getPotencia() );
            System.out.printf ("b2 -> tiempo encendida: %.2f\n", b2.getTiempoEncendida() );
            System.out.println ();
            
            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();
 
            System.out.println("Apagamos b1");
            b1.apagar();
            
            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();

            System.out.println("Creamos objeto Bombilla b3 con 100W de potencia  y encendida");
            b3 = new Bombilla (true, 100.0);

            System.out.println("Observamos valores de clase:");
            System.out.printf ("N�mero total de bombillas creadas: %d\n",
                    Bombilla.getBombillasCreadas() ); 
            System.out.printf ("N�mero de bombillas encendidas: %d\n",
                    Bombilla.getBombillasEncendidas() );
            System.out.println ();
            
        }
    
}