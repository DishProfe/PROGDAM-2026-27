
package ejemplos2026;

/**
 * Programa LANZANDO LOS DADOS
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class LanzarDados02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado d1, d6;
            int numCaras;
            String lanzamiento;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LANZANDO LOS DADOS");
            System.out.println("------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            // 1. Intentos de creaci�n de dados de 0 a 20 caras
            for ( numCaras = 0  ; numCaras<=20 ; numCaras++ ) {
                try {
                    d1 = new Dado ( numCaras );
                    System.out.printf ("Dado de %d caras creado con �xito\n", numCaras);
                } catch ( IllegalArgumentException ex ) {
                    System.out.printf("Error al intentar crear dado de %d caras\n",
                            numCaras);
                }
            }
            System.out.println ();
            
            // 2. Crear objeto Dado de 6 caras
            d6 = new Dado ();
            System.out.println("Creado un dado con 6 caras usando el constructor sin par�metros.");
            System.out.println ();
            
            // 3. Primer lanzamiento
            lanzamiento = d6.lanzar();
            System.out.printf ("Llevamos a cabo un primer lanzamiento: %s.\n",
                    lanzamiento);
            System.out.printf ("N�mero de total de lanzamientos llevados a cabo hasta el momento: %d.\n",
                    d6.getNumeroLanzamientos());
            System.out.println ();
            
            // 4. Nueve lanzamientos m�s
            System.out.println("Llevamos a cabo otros 9 lanzamientos.");
            for ( int contador = 1; contador<=9 ; contador++ ) {
                lanzamiento = d6.lanzar();
                System.out.printf ( "%s  ", lanzamiento );
            }
            System.out.println ();
            System.out.println ();

            // 4.1. Cantidad total de lanzamientos
            System.out.printf ("N�mero de total de lanzamientos llevados a cabo hasta el momento: %d.\n",
                    d6.getNumeroLanzamientos());
            
            // 4.2. N�mero de veces que se ha obtenido cada cara
            System.out.println("An�lisis de los lanzamientos llevados a cabo hasta el momento:");
            for ( int contador = 1; contador <= d6.getNumeroCaras() ; contador++ ) {
                System.out.printf ("N�mero de veces que se ha obtenido %d: %d\n", 
                        contador,
                        d6.getNumeroVecesCara(contador));
            }
            System.out.println ();
            
        
	}
    
}