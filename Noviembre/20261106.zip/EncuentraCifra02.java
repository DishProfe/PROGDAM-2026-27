
package ejemplos2026;

/**
 * Programa BUSCADOR DE CIFRAS
 * @author diosdado
 */

import java.util.Scanner;


public class EncuentraCifra02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long valInicial, valFinal;
            long cifra;
            


            // Variables de salida
            int numVeces;
            String listaNumeros;

            // Variables auxiliares
            long numero;
            long residuo;
            long resto;
            boolean cifraEncontrada;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("BUSCADOR DE CIFRAS");
            System.out.println("------------------");
            System.out.println("Introduzca rango (valor inicial y valor final): ");
            valInicial = teclado.nextLong();
            valFinal = teclado.nextLong();
            System.out.println("Introduzca cifra (0-9): ");
            cifra = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            numVeces = 0;
            listaNumeros= "";
            
            for ( numero = valInicial ; numero <= valFinal ; numero++ ) {
                residuo = numero;
                cifraEncontrada = false;
                do {
                    resto = residuo % 10;
                    residuo = residuo / 10;
                    if ( cifra == resto) {
                        cifraEncontrada = true;
                        numVeces++;
                        listaNumeros = listaNumeros + numero + " ";                    }
                } while ( residuo > 0 && !cifraEncontrada ); 
                
            }




            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Hay %d n�meros entre %d y %d que contienen la cifra %d:\n",
                    numVeces, valInicial, valFinal, cifra);
            System.out.println (listaNumeros);
            
	}
    
}