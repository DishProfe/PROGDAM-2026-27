
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EncuentraCifra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;
            long cifra;
            


            // Variables de salida
            boolean cifraEncontrada;


            // Variables auxiliares
            long residuo;
            long resto;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("BUSCADOR DE CIFRAS");
            System.out.println("------------------");
            System.out.println("Introduzca n�mero positivo: ");
            numero = teclado.nextLong();
            System.out.println("Introduzca cifra (0-9): ");
            cifra = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            residuo = numero;
            cifraEncontrada = false;
            do {
                resto = residuo % 10;
                residuo = residuo / 10;
                if ( cifra == resto) {
                    cifraEncontrada = true;
                }
            } while ( residuo > 0 && !cifraEncontrada );
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d contiene a la cifra %d: %b\n",
                    numero, cifra, cifraEncontrada);

        
	}
    
}