
package ejemplos2026;

/**
 * Programa SIGUIENTE PRIMO
 * @author diosdado
 */

import java.util.Scanner;


public class SiguientePrimo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int siguientePrimo;


            // Variables auxiliares
            boolean esPrimo;
            int candidatoDivisor;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SIGUIENTE PRIMO");
            System.out.println("---------------");
            System.out.println("Introduzca n�mero positivo > 1");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // El primer candidato a siguiente primo es el siguiente n�mero (+1)
            siguientePrimo = numero + 1;
             
            do {
                // Comprobamos si siguientePrimo ya es primo
                esPrimo = true;
                candidatoDivisor = 2;
                do {
                    if ( siguientePrimo % candidatoDivisor == 0 ) {
                        esPrimo = false;
                    }
                } while ( esPrimo && candidatoDivisor++ <= Math.sqrt(siguientePrimo)) ;

                if ( !esPrimo ) {
                    siguientePrimo++;
                }
            } while ( !esPrimo ); // Mientras siguientePrimo no sea primo hay que volver a intentar con el siguiente (+1)
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El siguiente primo a %d es %d\n",
                    numero, siguientePrimo);

        
	}
    
}