
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class EscaleraPrimos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int MIN_FILAS =  1;
            final int MAX_FILAS = 16;

            // Variables de entrada
            int numFilas;


            // Variables de salida



            // Variables auxiliares
            int contadorFilas, contadorColumnas;
            int numero;
            boolean esPrimo;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ESCALERA");
            System.out.println("--------");
            do {
                System.out.println("Introduzca n�mero de filas: (1-16)");
                numFilas = teclado.nextInt();                
            } while ( numFilas < MIN_FILAS || numFilas > MAX_FILAS );


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            numero = 2;
            for ( contadorFilas = 1 ; contadorFilas<=numFilas ; contadorFilas++ ) {
                System.out.printf ("%2d: ", contadorFilas);
                for ( contadorColumnas = 1; contadorColumnas<=contadorFilas ; contadorColumnas++  ) {
                    
                    // Comprobar si "numero" es primo
                    // Si no lo es, avanzar hasta que encuentre un primo
                    do {
                        // Comprobaci�n de si "numero" es primo
                        esPrimo = true;
                        int posibleDivisor = 2;
                        do {
                            // Comprobamos si numero es divisible entre posibleDivisor
                            esPrimo = numero % posibleDivisor != 0  || numero == 2;

                            // Incrementamos el contador para la pr�xima prueba
                            posibleDivisor++;
                        } while ( esPrimo && posibleDivisor <= numero / 2 ); // Nos salimos cuando superemos la mitad del n�mero

                        // Si "numero" no es primo habr� que probar con el siguiente
                        if ( !esPrimo ) {
                            numero++;
                        }
                        
                    } while ( !esPrimo ); // Si no es primo, repetimos el bucle con numero++

                    // Si hemos salido del bucle es porque hemos encontrado un primo
                    // (la variable numero contiene un primo)
                    System.out.printf ("%3d ", numero++);
                    
                }
                System.out.println();
            }
	}
    
}