
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Tallas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String talla;
            


            // Variables de salida
            int totalPeticiones;
            int totalPrendas;
            int totalXXL, totalXL, totalL, totalM, totalS, totalXS;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //                       +
            //                 Procesamiento 
            //----------------------------------------------
            System.out.println("CONTADOR DE TALLAS");
            System.out.println("------------------");

            
            totalPrendas = 0;
            totalPeticiones = 0;
            totalXXL = 0;
            totalXL = 0;
            totalL = 0;
            totalM = 0;
            totalS = 0;
            totalXS = 0;
            
            do {

                System.out.println("Introduzca talla: ");
                talla = teclado.nextLine();
                totalPeticiones++;
                
                switch ( talla ) {
                    
                    case "XXL":
                        totalXXL++;
                        totalPrendas++;                        
                        break;
                    
                    case "XL":
                        totalXL++;
                        totalPrendas++;                        
                        break;
                    
                    case "L":
                        totalL++;
                        totalPrendas++;                        
                        break;

                    case "M":
                        totalM++;
                        totalPrendas++;                        
                        break;

                    case "S":
                        totalS++;
                        totalPrendas++;                        
                        break;

                    case "XS":
                        totalXS++;
                        totalPrendas++;                        
                        break;
                        
                    case "FIN":
                        totalPeticiones--;
                        break;

                }
                 
                
            } while ( !talla.equalsIgnoreCase("FIN") );

            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("N�mero total de peticiones: %2d\n", totalPeticiones);
            System.out.printf ("N�mero total de prendas:    %2d\n", totalPrendas);
            System.out.printf ("N�mero de prendas XXL:      %2d\n", totalXXL);
            System.out.printf ("N�mero de prendas XL:       %2d\n", totalXL);
            System.out.printf ("N�mero de prendas L:        %2d\n", totalL);
            System.out.printf ("N�mero de prendas M:        %2d\n", totalM);
            System.out.printf ("N�mero de prendas S:        %2d\n", totalS);
            System.out.printf ("N�mero de prendas XS:       %2d\n", totalXS);


        
	}
    
}