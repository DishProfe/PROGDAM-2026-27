
package ejemplos2026;

/**
 * Programa INVERTIR TEXTOS
 * @author diosdado
 */

import java.util.Scanner;


public class TextoInverso01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            String textoInverso;


            // Variables auxiliares
            int indice;
            int longTexto;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("INVERTIR TEXTOS");
            System.out.println("---------------");
            System.out.println("Introduzca texto: ");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            textoInverso = "";
            longTexto = texto.length();
            for ( indice = 0  ; indice < longTexto ; indice++  ) {
                
                char c = texto.charAt(indice);
                textoInverso = c + textoInverso;
                
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto invertido es: %s\n", textoInverso);

        
	}
    
}