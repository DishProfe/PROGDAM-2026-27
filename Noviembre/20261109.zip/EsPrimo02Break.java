
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EsPrimo02Break {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;


            // Variables de salida
            boolean esPrimo;
            
            // Variables auxiliares
            long posibleDivisor;
            boolean entradaValida;
            boolean encontradoDivisor;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO SI UN N�MERO ES PRIMO");
            System.out.println("-----------------------------");

            do {
                System.out.println("Introduzca n�mero entero positivo: ");
                numero = teclado.nextLong();
                entradaValida = numero > 0;
            } while ( !entradaValida );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Valor inicial de esPrimo (supongo que es primo)
            esPrimo = true;
            
            // Primer valor del contador
            posibleDivisor = 2;
            do {
                // Comprobamos si numero es divisible entre posibleDivisor
                if ( numero % posibleDivisor == 0 ){
                    esPrimo = false;
                    break;
                }

                // Incrementamos el contador para la pr�xima prueba
                posibleDivisor++;
            } while (  posibleDivisor <= Math.sqrt(numero)); // Nos salimos cuando superemos la mitad del n�mero
            

            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero %d es primo: %b\n", numero, esPrimo);

        
	}
    
}