
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EjemploBreak03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int inicio, fin;



            // Variables de salida



            // Variables auxiliares
            int vi, vf;
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTADOR USANDO BUCLE Y BREAK");
            System.out.println("-----------------------------");
            System.out.println("Introduzca valores inicial y final: ");
            inicio = teclado.nextInt();
            fin = teclado.nextInt();
            
            vi = Math.min ( inicio, fin);
            vf = Math.max ( inicio, fin);
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            contador = vi;
            while ( true ) {
                if ( contador > vf ) {
                    break;
                }
                System.out.printf ("%d ", contador++);
            }
            System.out.println();
        
	}
    
}