
package ejemplos2026;

/**
 * Programa EJEMPLOS DE USO DE OBJETOS
 * @author diosdado
 */

import java.util.Scanner;
import java.awt.Rectangle;

import java.awt.Rectangle;
public class Objetos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            int e1, e2, e3;
            long n1, n2, n3;
            String t1, t2, t3;
                    
            Rectangle r1, r2, r3, r4, r5, r6;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OBJETOS");
            System.out.println("--------------------------");
            System.out.println();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            r1 = new Rectangle(); 
            r2 = new Rectangle (3, 2, 3, 2);
            r3 = new Rectangle (7, 1);
            r4 = new Rectangle ( r2 );
            
            r5 = r2;
            r6 = r3;
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("r1 = %s\n", r1);
            System.out.printf ("r2 = %s\n", r2);
            System.out.printf ("r3 = %s\n", r3);
            System.out.printf ("r4 = %s\n", r4);
            System.out.println();
            

            System.out.printf ("r2 == r4 -> %s\n", r2 == r4);
            System.out.printf ("r2 == r5 -> %s\n", r2 == r5);
            System.out.printf ("r2.equals(r4) -> %s\n", r2.equals(r4));
            System.out.printf ("r2.equals(r5) -> %s\n", r2.equals(r5));
            System.out.println();
            
            
            System.out.printf("r2.contains (0,0) -> %s\n", r2.contains (0,0));
            System.out.printf("r2.contains (4,3) -> %s\n", r2.contains (4,3));
            System.out.println();
            
            System.out.printf("r2.contains (4,2,2,1) -> %s\n", r2.contains (4,2,2,1));
            System.out.printf("r2.contains (0,0,2,2) -> %s\n", r2.contains (0,0,2,2));
            System.out.println();

            System.out.printf("r2.getX() -> %.2f\n",  r2.getX());
            System.out.printf("r2.getY() -> %.2f\n",  r2.getY());
            System.out.printf("r2.getWidth() -> %.2f\n",  r2.getWidth ());
            System.out.printf("r2.getHeight() -> %.2f\n", r2.getHeight ());
            System.out.println();
            
            
	}
    
}