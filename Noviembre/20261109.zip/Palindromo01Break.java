
package ejemplos2026;

/**
 * Programa DETECTOR DE PAL�NDROMOS
 * @author diosdado
 */

import java.util.Scanner;


public class Palindromo01Break {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            boolean esPalindromo;


            // Variables auxiliares
            int indice;
            int longitudTexto;
                    

            
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DETECTOR DE PAL�NDROMOS");
            System.out.println("-----------------------");
            System.out.println("Introduzca texto: ");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            longitudTexto = texto.length();
            esPalindromo = true;
            
            
            indice = 0;
            while ( indice < longitudTexto/2 ) {
                
                if (texto.charAt(indice) != texto.charAt(longitudTexto-1-indice)) {
                    esPalindromo = false;
                    break;
                }
                indice++;
            }            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto es pal�ndromo: %b\n",
                    esPalindromo);

        
	}
    
}