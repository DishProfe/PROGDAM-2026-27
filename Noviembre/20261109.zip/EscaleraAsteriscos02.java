
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class EscaleraAsteriscos02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numFilas;



            // Variables de salida



            // Variables auxiliares
            int fila;
            int columna;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ESCALERA DE ASTERISCOS");
            System.out.println("----------------------");
            System.out.println("Introduzca n�mero de filas: ");
            numFilas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            fila = 1;
            while ( fila <= numFilas ) {
                columna = 1;
                while ( columna <= fila ) { 
                    System.out.print ("*");
                    columna++;
                }
                fila++;
                System.out.println();
            }
            
            
            

        
	}
    
}