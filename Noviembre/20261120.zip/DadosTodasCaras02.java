
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DadosTodasCaras02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numCaras;



            // Variables de salida



            // Variables auxiliares
            Dado dado1, dado2;
            String lanz1, lanz2;
            boolean dado1Completo, dado2Completo;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DADOS");
            System.out.println("--------------");
            System.out.println("Gana el jugador que saque antes todas las caras");

            // Solicitamos el n�mero de caras hasta que sea correcto
            do {
                System.out.println("Introduzca el n�mero de caras de los dados: (4, 6, 8, 12, 20)");
                numCaras = teclado.nextInt();
            } while ( numCaras != 4 && numCaras != 6 && numCaras != 8 && numCaras != 12 && numCaras !=20 );
            
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado(numCaras);
            dado2 = new Dado(numCaras);
            
            int contador = 1;
            do {
                
                lanz1 = dado1.lanzar();
                lanz2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %16s  %16s\n", 
                        contador++, lanz1, lanz2);
                
                
                dado1Completo = true;
                for ( int cara = 1; cara <= dado1.getNumeroCaras() && dado1Completo ; cara++ ) {
                    dado1Completo = dado1Completo && dado1.getNumeroVecesCara(cara)>0;
                }
                
                dado2Completo = true;
                for ( int cara = 1; cara <= dado2.getNumeroCaras() && dado2Completo ; cara++ ) {
                    dado2Completo = dado2Completo && dado2.getNumeroVecesCara(cara)>0;
                }
                
            } while ( !dado1Completo && !dado2Completo );


            
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( dado1Completo ) {
                System.out.println("El ganador el jugador 1");
            } else {
                System.out.println("El ganador el jugador 2");
            }
            
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

