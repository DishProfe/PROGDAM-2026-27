
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DadosTodasCaras03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numCaras;



            // Variables de salida
            long puntosDado1, puntosDado2;



            // Variables auxiliares
            Dado dado1, dado2;
            String lanz1, lanz2;
            boolean dado1Completo, dado2Completo;
            int primeroEnTerminar;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DADOS");
            System.out.println("--------------");
            System.out.println("Se deja de lanzar dados cuando ambos hayan sacado todas las caras");
            System.out.println("Gana el jugador que saque m�s puntos");

            // Solicitamos el n�mero de caras hasta que sea correcto
            do {
                System.out.println("Introduzca el n�mero de caras de los dados: (4, 6, 8, 12, 20)");
                numCaras = teclado.nextInt();
            } while ( numCaras != 4 && numCaras != 6 && numCaras != 8 && numCaras != 12 && numCaras !=20 );
            
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado(numCaras);
            dado2 = new Dado(numCaras);
            
            int contador = 1;
            primeroEnTerminar = 0;
            do {
                
                lanz1 = dado1.lanzar();
                lanz2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %16s  %16s\n", 
                        contador++, lanz1, lanz2);
                
                
                dado1Completo = true;
                for ( int cara = 1; cara <= dado1.getNumeroCaras() && dado1Completo ; cara++ ) {
                    dado1Completo = dado1Completo && dado1.getNumeroVecesCara(cara)>0;
                }
                
                dado2Completo = true;
                for ( int cara = 1; cara <= dado2.getNumeroCaras() && dado2Completo ; cara++ ) {
                    dado2Completo = dado2Completo && dado2.getNumeroVecesCara(cara)>0;
                }
                
                
                if ( dado1Completo && !dado2Completo ) {
                    primeroEnTerminar = 1;
                }

                if ( !dado1Completo && dado2Completo ) {
                    primeroEnTerminar = 2;
                }

                
            } while ( !dado1Completo || !dado2Completo );


            
            puntosDado1 = dado1.getSumaPuntuacionHistorica();
            puntosDado2 = dado2.getSumaPuntuacionHistorica();


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( puntosDado1 > puntosDado2 ) {
                System.out.printf ("El ganador el jugador 1 con %d puntos frente a %d puntos.\n",
                        puntosDado1, puntosDado2);
            } else if ( puntosDado1 < puntosDado2 ) {
                System.out.printf ("El ganador el jugador 2 con %d puntos frente a %d puntos.\n",
                        puntosDado2, puntosDado1);
            } else {
                System.out.printf ("Empate a %d puntos.\n", puntosDado1);
                if ( primeroEnTerminar == 1 ) {
                    System.out.println("El gandor el jugador 1 porque consigui� antes todas las caras.\n");
                } else if ( primeroEnTerminar == 2 ) {
                    System.out.println("El gandor el jugador 2 porque consigui� antes todas las caras.\n");
                } 
            }
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

