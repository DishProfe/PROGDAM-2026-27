
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.InputMismatchException;
import java.util.Scanner;


public class ComprobacionEntrada01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int numero;
            int intentos;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PLANTILLA DE PROGRAMA");
            System.out.println("---------------------");
            System.out.println(" ");

            numero=-1;
            intentos=0;

            do {
              try {
                System.out.print ("Introduzca un n�mero entero entre 0 y 100: ");
                numero = teclado.nextInt();
              } catch (InputMismatchException e) {
                System.out.println("Error al leer del teclado.");
                teclado.nextLine(); // Vaciamos el buffer
              } finally {
                intentos++;
              }
            } while (numero < 0 || numero > 100);

            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("El n�mero introducido es: " + numero);
            System.out.println("N�mero de intentos: " + intentos);


        
        
	}
    
}

