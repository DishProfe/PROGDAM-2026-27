
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class TablaFormato01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS CON FORMATO");
            System.out.println("----------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            System.out.println ("+---------------------+");
            for ( int fila = 0 ; fila <= 9 ;  fila++ ) {
                
                double num = 10 + fila;
                
                System.out.printf ("| %5.2f  %5.2f  %5.2f |\n",
                        num, num+0.10, num+0.20);
                
            }
            System.out.println ("+---------------------+");
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

