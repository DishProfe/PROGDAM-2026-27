
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DadosTodasCaras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado dado1, dado2;
            String lanz1, lanz2;
            boolean dado1Completo, dado2Completo;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DADOS");
            System.out.println("--------------");
            System.out.println("Gana el jugador que saque antes todas las caras");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado();
            dado2 = new Dado();
            
            int contador = 1;
            do {
                
                lanz1 = dado1.lanzar();
                lanz2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %8s  %8s\n", 
                        contador++, lanz1, lanz2);
                
                
                dado1Completo = 
                    dado1.getNumeroVecesCara(1)>0 &
                    dado1.getNumeroVecesCara(2)>0 &
                    dado1.getNumeroVecesCara(3)>0 &
                    dado1.getNumeroVecesCara(4)>0 &
                    dado1.getNumeroVecesCara(5)>0 &
                    dado1.getNumeroVecesCara(6)>0;
                        
                dado2Completo = 
                    dado2.getNumeroVecesCara(1)>0 &
                    dado2.getNumeroVecesCara(2)>0 &
                    dado2.getNumeroVecesCara(3)>0 &
                    dado2.getNumeroVecesCara(4)>0 &
                    dado2.getNumeroVecesCara(5)>0 &
                    dado2.getNumeroVecesCara(6)>0;
                
                
            } while ( !dado1Completo && !dado2Completo );


            
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( dado1Completo ) {
                System.out.println("El ganador el jugador 1");
            } else {
                System.out.println("El ganador el jugador 2");
            }
            
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

