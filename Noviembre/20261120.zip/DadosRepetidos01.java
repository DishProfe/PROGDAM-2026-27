
package ejemplos2026;

/**
 * Programa Lanzamiento de dos dados y cara m�s frecuente
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Dado;

public class DadosRepetidos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int caraMasFrecuente;
            int numVecesCaraMasFrecuente;


            // Variables auxiliares
            Dado dado1, dado2;
            String lanzamiento1, lanzamiento2;
            String lanzamiento1Anterior, lanzamiento2Anterior;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("Lanzamiento de dos dados y cara m�s frecuente");
            System.out.println("---------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //                       +
            //              Salida de resultados 
            //----------------------------------------------

            // Creamos los objetos de tipo Dado
            dado1 = new Dado ();
            dado2 = new Dado ();

            lanzamiento1 ="";           
            lanzamiento2 ="";

            // Repetimos lanzamientos mientras
            // no se de lanz1==lanz1Ant y lanz2==lanz2Ant
            int contador = 1;
            do {
                // Conservamos el valor anterior de los lanzamientos
                lanzamiento1Anterior = lanzamiento1;
                lanzamiento2Anterior = lanzamiento2;

                // Hacemos un nuevo lanzamiento
                lanzamiento1 = dado1.lanzar();
                lanzamiento2 = dado2.lanzar();

                
                System.out.printf ("Lanzamiento %2d: %6s - %6s\n",
                        contador++, lanzamiento1, lanzamiento2);
                
            } while ( !lanzamiento1.equals(lanzamiento1Anterior) || 
                      !lanzamiento2.equals(lanzamiento2Anterior) );
            
            // Una vez finalizados los lanzamientos:
            // Obtenemos la cara m�s frecuente
            caraMasFrecuente = 0;
            numVecesCaraMasFrecuente = 0;
            for ( contador = 1; contador <= dado1.getNumeroCaras() ; contador++ ) {
                int veces = Dado.getNumeroVecesCaraGlobal(contador);
                if ( veces > numVecesCaraMasFrecuente ) {
                    caraMasFrecuente = contador;
                    numVecesCaraMasFrecuente = veces;
                }
            }
                 
            System.out.printf ("La cara que m�s veces ha salido ha sido: %d\n",
                    caraMasFrecuente);
            System.out.printf ("Con una frecuencia de %d veces.",
                    numVecesCaraMasFrecuente);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

