
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class FormateoReales01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double numero;
            int numDecimales;
            int anchura;


            // Variables de salida
            String cadenaFormato;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FORMATEO DE N�MEROS REALES");
            System.out.println("--------------------------");

            System.out.print("Introduzca n�mero real: ");
            numero= teclado.nextDouble();

            System.out.print("Introduzca n�mero de decimales visibles: ");
            numDecimales= teclado.nextInt();
            
            System.out.print("Introduzca la anchura: ");
            anchura= teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Fabricamos la cadena de formato adecuada para los valores
            // solicitados (anchura y n�mero de decimales visibles)
            cadenaFormato = "El n�mero real con el formato solicitado es: \"%" + 
                    anchura + "." + numDecimales + "f\"\n";
                    



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
//            System.out.printf ("El n�mero real con el formato solicitado es: \"%10.3f\"\n",                     numero);
            System.out.printf (cadenaFormato, numero);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

