
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DosTiradasRepetidas03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_CARAS = 4;

            // Variables de entrada




            // Variables de salida
            int ganador;
            long puntuacionGanador;


            // Variables auxiliares
            Dado dado1, dado2;
            String lanzamiento1, lanzamiento2;
            String lanzamiento1Anterior, lanzamiento2Anterior;
            int contador;
            
            long puntuacion1, puntuacion2;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DOS TIRADAS DREPETIDAS");
            System.out.println("-------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado(NUM_CARAS);
            dado2 = new Dado(NUM_CARAS);

            contador = 1;
            lanzamiento1 = "";
            lanzamiento2 = "";
            do {

                lanzamiento1Anterior = lanzamiento1;
                lanzamiento2Anterior = lanzamiento2;
                lanzamiento1 = dado1.lanzar();
                lanzamiento2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %11s - %11s\n",
                        contador++, lanzamiento1, lanzamiento2);
                
                
            } while ( !lanzamiento1.equals( lanzamiento1Anterior ) || 
                    !lanzamiento2.equals( lanzamiento2Anterior ));
            
            // Se decide el ganador por puntos
            puntuacion1 = dado1.getSumaPuntuacionHistorica();
            puntuacion2 = dado2.getSumaPuntuacionHistorica();

            ganador = 0;
            puntuacionGanador = 0;
            if ( puntuacion1 > puntuacion2 ) {
                ganador = 1;
                puntuacionGanador = puntuacion1;
            } else if ( puntuacion2 > puntuacion1 ){
                ganador = 2;
                puntuacionGanador = puntuacion2;                
            } 


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( ganador != 0 ) {
                System.out.printf ("El ganador es el jugador %d con puntuaci�n %d\n",
                        ganador, puntuacionGanador);
            } else {
                System.out.printf ("Se ha producido un empate con %d puntos\n",
                        puntuacion1);
            }


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}