
package ejemplos2026;

/**
 * Programa EJEMPLOS DE USO DE FECHA
 * @author diosdado
 */

import java.util.Scanner;
import java.time.LocalDate;
import java.time.Month;


public class EjemplosFecha01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            LocalDate fecha1, fecha2, fecha3, fecha4, fecha5, fecha6;
            
            LocalDate f1, f2, f3, f4, f5, f6;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE FECHA");
            System.out.println("------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            fecha1 = LocalDate.of (2026, 11, 23);
            // No existe constructor equivalente: new LocalDate (2026,11,23)
            
            fecha2 = LocalDate.of (2026, Month.NOVEMBER, 23);
            
            fecha3 = LocalDate.ofYearDay (2026, 40);
            
            fecha4 = LocalDate.now();

            fecha5 = LocalDate.parse ("2026-12-24");
            
            
            f1 = fecha1.plusDays(5);
            f2 = fecha1.plusDays(10);
            f3 = f1.plusDays(5);
            f4 = fecha1.plusDays (70);

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Fecha1:");
            System.out.printf ("getDayOfMonth= %d, getMonthValue= %d, getMonth= %s, getYear= %d\n",
                    fecha1.getDayOfMonth(), fecha1.getMonthValue(),
                    fecha1.getMonth(), fecha1.getYear() );
            System.out.printf ("getDayOfWeek= %s, getDayOfYear= %d, isLeapYear= %b, lengthOfMonth= %d\n",
                    fecha1.getDayOfWeek(), fecha1.getDayOfYear(), fecha1.isLeapYear(), fecha1.lengthOfMonth());
            System.out.printf ("lengthOfYear = %d\n",
                    fecha1.lengthOfYear());
            
            System.out.printf ("Fecha1 = %s\n", fecha1.toString() );
            System.out.printf ("f1     = %s\n", f1.toString() );
            System.out.printf ("f2     = %s\n", f2.toString() );
            System.out.printf ("f3     = %s\n", f3.toString() );
            System.out.printf ("f4     = %s\n", f4.toString() );
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}