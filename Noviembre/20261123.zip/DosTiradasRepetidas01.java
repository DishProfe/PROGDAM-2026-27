
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DosTiradasRepetidas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado dado1;
            String lanzamiento1;
            String lanzamiento1Anterior;
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DOS TIRADAS DREPETIDAS");
            System.out.println("-------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado();

            contador = 1;
            lanzamiento1 = "";
            do {

                lanzamiento1Anterior = lanzamiento1;
                lanzamiento1 = dado1.lanzar();
                System.out.printf ("Lanzamiento %2d: %11s\n",
                        contador++, lanzamiento1);
                
                
            } while ( !lanzamiento1.equals( lanzamiento1Anterior ) );
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}