
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class DosTiradasRepetidas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Dado dado1, dado2;
            String lanzamiento1, lanzamiento2;
            String lanzamiento1Anterior, lanzamiento2Anterior;
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DOS TIRADAS DREPETIDAS");
            System.out.println("-------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado();
            dado2 = new Dado();

            contador = 1;
            lanzamiento1 = "";
            lanzamiento2 = "";
            do {

                lanzamiento1Anterior = lanzamiento1;
                lanzamiento2Anterior = lanzamiento2;
                lanzamiento1 = dado1.lanzar();
                lanzamiento2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %11s - %11s\n",
                        contador++, lanzamiento1, lanzamiento2);
                
                
            } while ( !lanzamiento1.equals( lanzamiento1Anterior ) && 
                    !lanzamiento2.equals( lanzamiento2Anterior ));
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}