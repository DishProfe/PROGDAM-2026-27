
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Scanner;


public class TodasLasCaras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_CARAS = 6;

            // Variables de entrada




            // Variables de salida
            int ganador;
            long puntuacionGanador;


            // Variables auxiliares
            Dado dado1, dado2;
            String lanzamiento1, lanzamiento2;

            int contador;
            boolean hanSalidoTodas;
            long puntuacion1, puntuacion2;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO PARA QUE SALGAN TODAS LAS CARAS DEL DADO");
            System.out.println("----------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado(NUM_CARAS);
            dado2 = new Dado(NUM_CARAS);

            contador = 1;

            do {

                lanzamiento1 = dado1.lanzar();
                System.out.printf ("Lanzamiento %2d: %-11s\n", 
                        contador++, lanzamiento1);
                
                hanSalidoTodas = 
                        dado1.getNumeroVecesCara(1)>0 &&
                        dado1.getNumeroVecesCara(2)>0 && 
                        dado1.getNumeroVecesCara(3)>0 && 
                        dado1.getNumeroVecesCara(4)>0 && 
                        dado1.getNumeroVecesCara(5)>0 && 
                        dado1.getNumeroVecesCara(6)>0 ; 
                
                
            } while ( !hanSalidoTodas );
            
            // Se decide el ganador por puntos
        /*    puntuacion1 = dado1.getSumaPuntuacionHistorica();
            puntuacion2 = dado2.getSumaPuntuacionHistorica();

            ganador = 0;
            puntuacionGanador = 0;
            if ( puntuacion1 > puntuacion2 ) {
                ganador = 1;
                puntuacionGanador = puntuacion1;
            } else if ( puntuacion2 > puntuacion1 ){
                ganador = 2;
                puntuacionGanador = puntuacion2;                
            } 
*/

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
/*            if ( ganador != 0 ) {
                System.out.printf ("El ganador es el jugador %d con puntuaci�n %d\n",
                        ganador, puntuacionGanador);
            } else {
                System.out.printf ("Se ha producido un empate con %d puntos\n",
                        puntuacion1);
            }

*/
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}