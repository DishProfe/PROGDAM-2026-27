
package ejemplos2026;

/**
 * Programa LANZANDO DADOS
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Dado;

public class DosDadosIguales02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int ganador = 0;
            long puntuacionGanador = 0;

            // Variables auxiliares
            Dado dado1, dado2;
            String lanzamientoDado1, lanzamientoDado2;
            int contador;
            long puntuacion1, puntuacion2;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LANZANDO DADOS");
            System.out.println("--------------");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dado1 = new Dado ();
            dado2 = new Dado ();
            
            contador = 1;
            do {
                // Lanzamos los dos dados
                lanzamientoDado1 = dado1.lanzar();
                lanzamientoDado2 = dado2.lanzar();
                System.out.printf ("Lanzamiento %2d: %6s - %6s\n",
                        contador++, lanzamientoDado1, lanzamientoDado2);               
                
            } while ( !lanzamientoDado1.equals(lanzamientoDado2) );

            // Se decide el ganador por puntos
            puntuacion1 = dado1.getSumaPuntuacionHistorica();
            puntuacion2 = dado2.getSumaPuntuacionHistorica();
            if ( puntuacion1 > puntuacion2 ) {
                ganador = 1;
                puntuacionGanador = puntuacion1;
            } else if ( puntuacion2 > puntuacion1 ){
                ganador = 2;
                puntuacionGanador = puntuacion2;                
            } 
            
            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            if ( ganador != 0 ) {
                System.out.printf ("El ganador es el jugador %d con puntuaci�n %d\n",
                        ganador, puntuacionGanador);
            } else {
                System.out.printf ("Se ha producido un empate con %d puntos\n",
                        puntuacion1);
            }
            
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}