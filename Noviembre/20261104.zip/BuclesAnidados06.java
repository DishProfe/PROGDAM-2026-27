
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class BuclesAnidados06 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;
            int numColumnas;


            // Variables de salida



            // Variables auxiliares
            int contadorFilas, contadorColumnas;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS B�SICOS DE BUCLES ANIDADOS");
            System.out.println("---------------------");
            System.out.println("Introduzca n�mero de l�neas:");
            numLineas = teclado.nextInt();
            System.out.println("Introduzca n�mero de columnas:");
            numColumnas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            for ( contadorFilas = 1 ; contadorFilas<=numLineas ; contadorFilas++ ) {
                System.out.printf ("%d: ", contadorFilas);
                for ( contadorColumnas = 1; contadorColumnas<=numColumnas ; contadorColumnas++  ) {
                    System.out.printf ("%d ", contadorColumnas);
                }
                System.out.println();
            }
	}
    
}