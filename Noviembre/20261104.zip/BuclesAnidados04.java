
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class BuclesAnidados04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;


            // Variables de salida



            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS B�SICOS DE BUCLES ANIDADOS");
            System.out.println("---------------------");
            System.out.println("Introduzca n�mero de l�neas:");
            numLineas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            for ( contador = 1 ; contador<=numLineas ; contador++ ) {
                System.out.printf ("%d: 1 2 3 4 5 6 7 8 9 10 11\n", contador);
            }
            

        
	}
    
}