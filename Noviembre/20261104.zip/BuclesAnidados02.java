
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class BuclesAnidados02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int contador;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS B�SICOS DE BUCLES ANIDADOS");
            System.out.println("---------------------");
            System.out.println("");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            for ( contador = 1 ; contador<=5 ; contador++ ) {
                System.out.printf ("%d: 1 2 3 4 5\n", contador);
            }
            

        
	}
    
}