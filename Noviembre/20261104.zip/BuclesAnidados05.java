
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class BuclesAnidados05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;


            // Variables de salida



            // Variables auxiliares
            int contador1, contador2;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS B�SICOS DE BUCLES ANIDADOS");
            System.out.println("---------------------");
            System.out.println("Introduzca n�mero de l�neas:");
            numLineas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            for ( contador1 = 1 ; contador1<=numLineas ; contador1++ ) {
                System.out.printf ("%d: ", contador1);
                for ( contador2 = 1; contador2<=11 ; contador2++  ) {
                    System.out.printf ("%d ", contador2);
                }
                System.out.println();
            }
	}
    
}