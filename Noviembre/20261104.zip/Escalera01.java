
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class Escalera01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int MIN_FILAS =  1;
            final int MAX_FILAS = 16;

            // Variables de entrada
            int numFilas;


            // Variables de salida



            // Variables auxiliares
            int contadorFilas, contadorColumnas;
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ESCALERA");
            System.out.println("--------");
            do {
                System.out.println("Introduzca n�mero de filas: (1-16)");
                numFilas = teclado.nextInt();                
            } while ( numFilas < MIN_FILAS || numFilas > MAX_FILAS );


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            contador = 1;
            for ( contadorFilas = 1 ; contadorFilas<=numFilas ; contadorFilas++ ) {
                System.out.printf ("%2d: ", contadorFilas);
                for ( contadorColumnas = 1; contadorColumnas<=contadorFilas ; contadorColumnas++  ) {
                    System.out.printf ("%3d ", contador++);
                }
                System.out.println();
            }
	}
    
}