
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class BuclesAnidados08 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int MIN_FILAS =  1;
            final int MAX_FILAS = 16;
            final int MIN_COLUMNAS =  1;
            final int MAX_COLUMNAS = 16;

            // Variables de entrada
            int numLineas;
            int numColumnas;


            // Variables de salida



            // Variables auxiliares
            int contadorFilas, contadorColumnas;
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS B�SICOS DE BUCLES ANIDADOS");
            System.out.println("---------------------");
            do {
                System.out.println("Introduzca n�mero de l�neas: (1-16)");
                numLineas = teclado.nextInt();                
            } while ( numLineas < MIN_FILAS || numLineas > MAX_FILAS );

            do {
                System.out.println("Introduzca n�mero de columnas: (1-16)");
                numColumnas = teclado.nextInt();
            } while ( numColumnas < MIN_COLUMNAS || numColumnas > MAX_COLUMNAS );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            contador = 1;
            for ( contadorFilas = 1 ; contadorFilas<=numLineas ; contadorFilas++ ) {
                System.out.printf ("%2d: ", contadorFilas);
                for ( contadorColumnas = 1; contadorColumnas<=numColumnas ; contadorColumnas++  ) {
                    System.out.printf ("%3d ", contador++);
                }
                System.out.println();
            }
	}
    
}