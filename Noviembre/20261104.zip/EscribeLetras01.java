
package ejemplos2026;

/**
 * Programa PROGRAMA QUE MUESTRA LETRAS CONSECUTIVAS
 * @author diosdado
 */

import java.util.Scanner;


public class EscribeLetras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            char inicio;
            char fin;



            // Variables de salida



            // Variables auxiliares
            char contador;
            boolean entradaValida;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA QUE MUESTRA LETRAS CONSECUTIVAS");
            System.out.println("----------------------------------------");
            
            do {
                System.out.println("Introduzca l�mite inferior: ");
                inicio = teclado.nextLine().charAt(0);
                System.out.println("Introduzca l�mite superior: ");
                fin = teclado.nextLine().charAt(0);
                entradaValida =  inicio < fin;
                if ( !entradaValida ) {
                    System.out.println("ERROR. L�mite inferior debe de estar por debajo del superior");
                }               
            } while ( !entradaValida  );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            contador = inicio;
            do {
                System.out.println (contador);
                contador++;
            } while ( contador <= fin );

            
          

        
	}
    
}