
package ejemplos2026;

/**
 * Programa DETECTOR DE PAL�NDROMOS
 * @author diosdado
 */

import java.util.Scanner;


public class Palindromo02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            boolean esPalindromo;


            // Variables auxiliares
            int indice;
            int longitudTexto;
            String textoInverso;
                    

            
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DETECTOR DE PAL�NDROMOS");
            System.out.println("-----------------------");
            System.out.println("Introduzca texto: ");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Calculamos el texto inverso
            longitudTexto = texto.length();
            textoInverso = "";
            for ( indice = 0  ; indice < longitudTexto ; indice++  ) {
                
                char c = texto.charAt(indice);
                textoInverso = c + textoInverso;
                
            }

            esPalindromo = texto.equals (textoInverso);      


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto es pal�ndromo: %b\n",
                    esPalindromo);

        
	}
    
}