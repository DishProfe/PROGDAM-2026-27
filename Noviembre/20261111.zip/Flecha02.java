
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Flecha02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            int MAX_COLUMNAS = 10;
            

            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            int fila, columna;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FLECHA DE ASTERISCOS");
            System.out.println("--------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            // Vamos recorriendo filas
            for ( fila = 1 ; fila <= MAX_COLUMNAS*2 ; fila++ ) {

                // Pintamos la fila recorriendo las columnas
                if ( fila <= MAX_COLUMNAS ) {
                    // Si a�n no hemos llegado a la mitad:
                    // Vamos recorriendo columnas para cada fila
                    // Cada vez se pintan m�s asteriscos
                    for ( columna = 1 ; columna <= fila ; columna++ ) {
                        System.out.print ("*");
                    }
                } else {
                    // Si hemos superado la mitad:
                    // Vamos recorriendo columnas para cada fila
                    // Cada vez se pintan menos asteriscos
                    for ( columna = 1 ; columna <= MAX_COLUMNAS*2 - fila  ; columna++ ) {
                        System.out.print ("*");
                    }
                    
                }
                // Al final de pintar todas las columnas de un fila incluyo un avance de l�nea
                System.out.println();
            }
            
            
	}
    
}