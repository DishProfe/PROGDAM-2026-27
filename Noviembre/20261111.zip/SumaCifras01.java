
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class SumaCifras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int sumaCifras;


            // Variables auxiliares
            int residuo;
            int cifra;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SUMADOR DE CIFRAS");
            System.out.println("---------------");
            System.out.println("Introduzca n�mero:");
            numero = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            sumaCifras = 0;
            residuo = numero;
            
            while (residuo > 0) {
                
                // Obtengo la cifra de m�s a la derecha (resto de dividir entre 10)
                cifra = residuo % 10;

                // Quito la cifra de m�s a la derecha (cociente de dividir entre 10)
                residuo = residuo / 10 ;
                
                // Suma la cifra 
                sumaCifras += + cifra;
                
                
            }
            




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("La suma de las cifras de %d es %d\n", 
                    numero, sumaCifras);

        
	}
    
}