
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Capicua02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esCapicua;

            // Variables auxiliares
            int residuo;
            int cifra;
            int numeroInvertido;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE CAPIC�A");
            System.out.println("----------------------");
            System.out.println("Introduzca n�mero:");
            numero = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            // Calculamos el n�mero invertido
            numeroInvertido = 0;
            residuo = numero;
            while (residuo > 0) {
                // Obtengo la cifra de m�s a la derecha (resto de dividir entre 10)
                cifra = residuo % 10;
                // Quito la cifra de m�s a la derecha (cociente de dividir entre 10)
                residuo = residuo / 10 ;
                // A�ado la cifra al n�mero invertido
                numeroInvertido = numeroInvertido*10 + cifra;
            }
            

            // Comprobamos si el n�mero original es igual al invertido
            esCapicua = numero == numeroInvertido;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El n�mero es capic�a: %b\n", esCapicua);

        
	}
    
}