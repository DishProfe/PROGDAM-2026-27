
package ejemplos2026;

/**
 * Programa DIBUJO DE CAJAS
 * @author diosdado
 */

import java.util.Scanner;


public class Caja01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int altura, anchura;



            // Variables de salida



            // Variables auxiliares
            int fila, columna;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DIBUJO DE CAJAS");
            System.out.println("---------------");
            System.out.println("Introduzca anchura y altura de la caja: ");
            anchura = teclado.nextInt();
            altura = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Pintamos la primera fila (tapa superior)
            for ( columna = 1 ; columna<=anchura ; columna++ ) {
                System.out.print("*");
            }
            System.out.println();

            // Pintamos el resto de filas 
            for ( fila = 2 ; fila < altura ; fila++ ) {
                
                // Pintamos lazo izquierdo
                System.out.print("*");

                // Pintamos relleno
                for ( columna = 2 ; columna<anchura ; columna++ ) {
                    System.out.print(" ");
                }
                
                // Pintamos lazo derecho
                System.out.print("*");
                
                // Avance de l�nea
                System.out.println();
                
            }
            
            // Pintamos la �ltia fila (tapa inferior)
            for ( columna = 1 ; columna<=anchura ; columna++ ) {
                System.out.print("*");
            }
            System.out.println();
            

        
	}
    
}


