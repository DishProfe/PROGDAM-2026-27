
package ejemplos2026;

/**
 * Programa EJEMPLOS B�SICOS DE BUCLES ANIDADOS
 * @author diosdado
 */

import java.util.Scanner;


public class EscaleraLetras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int MIN_LETRA=  'A';
            final int MAX_LETRA = 'Z';

            // Variables de entrada
            char ultimaLetra;


            // Variables de salida



            // Variables auxiliares
            char contadorFilas, contadorColumnas;
            char contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ESCALERA");
            System.out.println("--------");
            do {
                System.out.println("Introduzca �ltima letra: (A-Z)");
                ultimaLetra = teclado.nextLine().charAt(0);                
            } while ( ultimaLetra < MIN_LETRA || ultimaLetra > MAX_LETRA );


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("");
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            contador = 'A';
            for ( contadorFilas = 'A' ; contadorFilas<=ultimaLetra ; contadorFilas++ ) {
                System.out.printf ("%2c: ", contadorFilas);
                for ( contadorColumnas = 'A'; contadorColumnas<=contadorFilas ; contadorColumnas++  ) {
                    System.out.printf ("%3c ", contadorColumnas);
                }
                System.out.println();
            }
	}
    
}