
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Flecha01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            int fila, columna;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FLECHA DE ASTERISCOS");
            System.out.println("--------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            // Pintamos primera parte (n�mero de asteriscos ascendente)
            // Vamos recorriendo filas
            for ( fila = 1 ; fila <= 5 ; fila++ ) {

                // Vamos recorriendo columnas para cada fila
                for ( columna = 1 ; columna <= fila ; columna++ ) {
                    System.out.print ("*");
                }
                // Al final de pintar todas las columnas de un fila incluyo un avance de l�nea
                System.out.println();
            }
            
            // Pintamos segunda parte (n�mero de asteriscos descendente)
            // Vamos recorriendo filas
            for ( fila = 4 ; fila >= 1 ; fila-- ) {

                // Vamos recorriendo columnas para cada fila
                for ( columna = 1 ; columna <= fila ; columna++ ) {
                    System.out.print ("*");
                }
                // Al final de pintar todas las columnas de un fila incluyo un avance de l�nea
                System.out.println();
            }            
            
	}
    
}