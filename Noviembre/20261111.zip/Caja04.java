
package ejemplos2026;

/**
 * Programa DIBUJO DE CAJAS
 * @author diosdado
 */

import java.util.Scanner;


public class Caja04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int altura, anchura;
            char relleno;



            // Variables de salida
            String caja;


            // Variables auxiliares
            int fila, columna;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DIBUJO DE CAJAS");
            System.out.println("---------------");
            System.out.println("Introduzca anchura y altura de la caja: ");
            anchura = teclado.nextInt();
            altura = teclado.nextInt();
            teclado.nextLine();
            System.out.println("Introduzca car�cter de relleno");
            relleno = teclado.nextLine().charAt(0);

            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            caja = "";

            // Generamos la primera fila (tapa superior)
            caja += "+";  // Esquina izquierda
            for ( columna = 2 ; columna<=anchura-1 ; columna++ ) {
                caja +="-";
            }
            caja += "+\n";  // Esquina derecha

            // Pintamos el resto de filas 
            for ( fila = 2 ; fila < altura ; fila++ ) {
                
                // Pintamos lazo izquierdo
                caja += "|";

                // Pintamos relleno
                for ( columna = 2 ; columna<anchura ; columna++ ) {
                    caja += relleno;
                }
                
                // Pintamos lazo derecho (y el avance de l�nea)
                caja += "|\n";
                
            }
            
            // Pintamos la �ltia fila (tapa inferior)
            caja += "+";  // Esquina izquierda
            for ( columna = 2 ; columna<=anchura-1 ; columna++ ) {
                caja +="-";
            }
            caja += "+\n";  // Esquina derecha
            
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (caja);

            

        
	}
    
}


