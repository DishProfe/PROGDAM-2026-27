/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos;

/**
 *
 * @author diosdado
 */
public class Programa02 {

    public static void main(String[] args) {
        
        int elemento1;
        int elemento2;
        int suma;
        
        System.out.println("Programa que suma dos n�meros");
        System.out.println("-----------------------------");
        System.out.println();
        
        elemento1 = 10;
        elemento2 = 20;
        
        suma = elemento1 + elemento2 ;
        
        System.out.print ("El primer elemento tiene valor: ");
        System.out.println (elemento1);
        System.out.print ("El segundo elemento tiene valor: ");
        System.out.println (elemento2);
        System.out.println();
        
        System.out.print ("El resultado de la suma es: ");
        System.out.println (suma);        
    }
    
}
