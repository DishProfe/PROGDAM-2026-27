/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplos;

import java.util.Scanner;


/**
 *
 * @author diosdado
 */
public class Programa04 {

    public static void main(String[] args) {

        // ---------
        // Variables
        // ---------
        
        int elemento1;
        int elemento2;
        int suma;
        int resta;
        int producto;
        int division;

        // Objeto Scanner para petici�n de datos de entrada        
        Scanner teclado= new Scanner (System.in);
        
        
        // ----------------
        // Entrada de datos
        // ----------------
        
        System.out.println("------------------------------");
        System.out.println("Programa que opera dos n�meros");
        System.out.println("------------------------------");
        System.out.println();

        System.out.println("Introduzca los datos de entrada");
        System.out.println("-------------------------------");

        
        System.out.print ("Introduzca el valor del elemento 1: ");
        elemento1 = teclado.nextInt();

        System.out.print ("Introduzca el valor del elemento 2: ");
        elemento2 = teclado.nextInt();
        
        
        // --------------------
        // Procesamiento
        // --------------------
        suma  =     elemento1 + elemento2 ;
        resta =     elemento1 - elemento2 ;
        producto =  elemento1 * elemento2 ;
        division =  elemento1 / elemento2 ;
        
        
        // --------------------
        // Salida de resultados
        // --------------------
        System.out.println();
        System.out.println ("RESULTADOS");
        System.out.println ("----------");
        System.out.print ("El primer elemento tiene valor: ");
        System.out.println (elemento1);
        System.out.print ("El segundo elemento tiene valor: ");
        System.out.println (elemento2);
        System.out.println();
       
        System.out.print ("El resultado de la suma es: ");
        System.out.println (suma);        

        System.out.print ("El resultado de la resta es: ");
        System.out.println (resta);        

        System.out.print ("El resultado de la multiplicaci�n es: ");
        System.out.println (producto);        

        System.out.print ("El resultado de la divisi�n es: ");
        System.out.println (division);        
  
    }
    
}
