/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos;

/**
 *
 * @author diosdado
 */
public class Programa03 {

    public static void main(String[] args) {
        
        int elemento1;
        int elemento2;
        int suma;
        int resta;
        int producto;
        int division;
        
        System.out.println("Programa que opera dos n�meros");
        System.out.println("------------------------------");
        System.out.println();
        
        elemento1 = 100;
        elemento2 = 20;
        
        suma  =     elemento1 + elemento2 ;
        resta =     elemento1 - elemento2 ;
        producto =  elemento1 * elemento2 ;
        division =  elemento1 / elemento2 ;

        
        System.out.print ("El primer elemento tiene valor: ");
        System.out.println (elemento1);
        System.out.print ("El segundo elemento tiene valor: ");
        System.out.println (elemento2);
        System.out.println();
        
        System.out.print ("El resultado de la suma es: ");
        System.out.println (suma);        

        System.out.print ("El resultado de la resta es: ");
        System.out.println (resta);        

        System.out.print ("El resultado de la multiplicaci�n es: ");
        System.out.println (producto);        

        System.out.print ("El resultado de la divisi�n es: ");
        System.out.println (division);        



    }
    
}
