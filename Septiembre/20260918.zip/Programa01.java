/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplos;

/**
 *
 * @author diosdado
 */
public class Programa01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.print ("Texto 1\n");
        System.out.print ("Texto 2\n");
        System.out.println ("Texto 3");
        System.out.println ("Texto 4\n");
        System.out.println ("Texto 5");
        System.out.print ("Texto 6\n\n");
        System.out.println ("Texto 7\n\n");
        System.out.printf ("Texto 8\n");
        System.out.print ("Texto 9.1  ");
        System.out.print ("  Texto 9.2");

        System.out.println();
        System.out.print("\n");


    }
    
}
