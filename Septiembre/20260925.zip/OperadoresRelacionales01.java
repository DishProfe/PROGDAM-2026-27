
package ejemplos;

/**
 * Programa OPERADORES RELACIONALES
 * @author diosdado
 */

import java.util.Scanner;


public class OperadoresRelacionales01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int x, y;

            // Variables de salida
            boolean esIgual;
            boolean esDistinto;
            boolean esMayor;
            boolean esMayorIgual;
            boolean esMenor;
            boolean esMenorIgual;
            
            
            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OPERADORES RELACIONALES");
            System.out.println("-----------------------");
            System.out.println();
            
            System.out.print( "Introducir el valor de x: " );
            x = teclado.nextInt(); // pedimos el primer n�mero al usuario

            System.out.print( "Introducir el valor de y: " );
            y = teclado.nextInt(); // pedimos el segundo n�mero al usuario

            //----------------------------------------------
            //               Procesamiento 
            //----------------------------------------------
            esIgual = x==y;
            esDistinto = x != y;
            esMayor = x > y;
            esMayorIgual = x >= y;
            esMenor = x < y;
            esMenorIgual = x <= y;
            
            //----------------------------------------------
            //             Salida de resultados
            //----------------------------------------------
            
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("x es igual a y: " + esIgual);
            System.out.println ("x es distinto de y: " + esDistinto);
            System.out.println ("x es mayor que y: " + esMayor);
            System.out.println ("x es mayor o igual que  y: " + esMayorIgual);
            System.out.println ("x es menor que y: " + esMenor);
            System.out.println ("x es menor o igual que y: " + esMenorIgual);
            
            
            
        
	}
    
}