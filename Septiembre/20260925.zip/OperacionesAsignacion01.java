
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperacionesAsignacion01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int x = 10;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OPERADORES DE ASIGNACI�N");
            System.out.println("-------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //    Procesamiento + Salida de resultados
            //----------------------------------------------


            System.out.println ();

            // x pasa a valer 5 (se le resta 5)
            x -= 5;  //  x = x - 5  // Restando 5
            System.out.println("x = " + x);
            
            // x pasa a valer 6 (se le suma 1)
            x += 1;  // x = x + 1  // Sumando 1
            System.out.println("x = " + x);

            // x pasa a valer 12
            // x += 6; // x = x + 6;  // Sumando 6
            x *= 2;  // x = x * 2  // Multiplicando por 2
            System.out.println("x = " + x);

            // x pasa a valer 6 
            // x -= 6;  //x = x - 6  // Restando 6
            x /= 2;  //x = x / 2  // Diviendo entre 2
            System.out.println("x = " + x);
            
            // x pasa a valer -4 (restando 10)
            x -= 10;  // x = x - 10
            System.out.println("x = " + x);
            
            // x pasa a valer 1
            // Sumando 5: x += 5  // x = x + 5
            // Diviendo entre -4:  x /=-4 // x = x / (-4)
            x /= -4;
            System.out.println("x = " + x);
            
            
	}
    
}