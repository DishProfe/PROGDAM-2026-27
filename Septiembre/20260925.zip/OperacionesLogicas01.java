
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperacionesLogicas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OPERADORES L�GICOS");
            System.out.println("-------------------------------------");
            System.out.println();
            System.out.println();


            //----------------------------------------------
            //                 Procesamiento
            //                       +
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("-------------------------------------");

            System.out.println("Negacion:\n !false es : " + (! false));
            System.out.println(" !true es : " + (! true));

            System.out.println();
            System.out.println("Operador AND (&):");
            System.out.println(" false & false es : " + (false & false));
            System.out.println(" false & true  es : " + (false & true));
            System.out.println(" true  & false es : " + (true & false));
            System.out.println(" true  & true  es : " + (true & true));

            System.out.println();
            System.out.println("Operador OR (|):");
            System.out.println(" false | false es : " + (false | false));
            System.out.println(" false | true  es : " + (false | true));
            System.out.println(" true  | false es : " + (true | false));
            System.out.println(" true  | true  es : " + (true | true));

            System.out.println();
            System.out.println("Operador OR Exclusivo o XOR (^):");
            System.out.println(" false ^ false es : "  + (false ^ false));
            System.out.println(" false ^ true  es : " + (false ^ true));
            System.out.println(" true  ^ false es : " + (true ^ false));
            System.out.println(" true  ^ true  es : " + (true ^ true));

            System.out.println();
            System.out.println("Operador AND (&&):");
            System.out.println(" false && false es : "  + (false && false));
            System.out.println(" false && true  es : " + (false && true));
            System.out.println(" true  && false es : " + (true && false));
            System.out.println(" true  && true  es : " + (true && true));

            System.out.println();
            System.out.println("Operador OR (||):");
            System.out.println(" false || false es : " + (false || false));
            System.out.println(" false || true  es : " + (false || true));
            System.out.println(" true  || false es : " + (true || false));
            System.out.println(" true  || true  es : " + (true || true));

        
	}
    
}