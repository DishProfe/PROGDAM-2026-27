
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperacionesLogicas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int x1=10, x2=5, x3=0;
            char c1='F', c2='S';



            // Variables de salida
            boolean pregunta1;  // x1 es igual a x2 
            boolean pregunta2;  // c1 es distinto a c2
            boolean pregunta3;  // x1 est� entre 10 y 100
            boolean pregunta4;  // x2 no est� entre 10 y 100
            boolean pregunta5;  // x2 no est� entre 10 y 100
            boolean pregunta6;  // x1 es mayor que x2 y c1 es igual a c2           
            boolean pregunta7;  // O x1 es mayor que x2, o c1 es distinto a c2, cualquiera de los dos casos.           
            boolean pregunta8;  // x1 es menor o igual que 7 y c2 es igual a c1           
            boolean pregunta9;  // c2 es distinto de 'A' y x2 es mayor que 0          
            boolean pregunta10; // 'F' es distinto de c1 o x1 es mayor que 20            
            boolean pregunta11; // 'F' es distinto de c1 o x1 es mayor que 20 o x2 es mayor que 2           
            boolean pregunta12; // 'F' es igual a c1 y x3 es menor que x1          
            boolean pregunta13; // 'F' es igual a c1 y x3 es menor que x1 y x2 es menor o igual que x3
            boolean pregunta14; // x2 est� entre x3 y x1, y c2 es 'S'           
            boolean pregunta15; // x3 no est� entre x2 y x1           
            boolean pregunta16; // x2 no est� entre x3 y x1, o c2 es igual a c1          
            boolean pregunta17; // no se cumple que x3 es menor que x1          
            boolean pregunta18; // ni x3 es mayor que x1, ni c2 es distinto a c1           
            boolean pregunta19; // no se cumple que x1 es menor que 100 y x2 es mayor que 10          
            boolean pregunta20; // c2 es anterior alfab�ticamente a c1          


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OPERADORES L�GICOS");
            System.out.println("-------------------------------------");
            System.out.println();
            System.out.println("x1 = " + x1);
            System.out.println("x2 = " + x2);
            System.out.println("x3 = " + x3);
            System.out.println("c1 = " + c1);
            System.out.println("c2 = " + c2);
            System.out.println();


            //----------------------------------------------
            //                 Procesamiento
            //----------------------------------------------

            // x1 es igual a x2
            pregunta1 = x1==x2;
            
            // c1 es distinto a c2
            pregunta2 = c1 != c2;
            
            // x1 est� entre 10 y 100
            pregunta3 = x1>=10 && x1<=100 ;

            // x2 no est� entre 10 y 100
            //pregunta4 = ! (x1>=10 && x1<=100);
            // pregunta4 = x2<10 || x2>100;
            pregunta4 = ! pregunta3;
            
            // x3 no est� entre 10 y 100
            pregunta5 = ! (x3>=10 && x3<=100);
            
            // x1 es mayor que x2 y c1 es igual a c2
            pregunta6 = x1 > x2 && c1==c2;
            
            // O x1 es mayor que x2, o c1 es distinto a c2, cualquiera de los dos casos 
            pregunta7 = x1>x2 ^  c1!=c2;

            // x1 es menor o igual que 7 y c2 es igual a c1 
            pregunta8 = x1<=7 && c2==c1;
            
            // c2 es distinto de 'A' y x2 es mayor que 0 
            pregunta9 = c2!='A' && x2>0;

            // 'F' es distinto de c1 o x1 es mayor que 20            
            pregunta10 = 'F'!=c1 || x1>20; 

            // 'F' es distinto de c1 o x1 es mayor que 20 o x2 es mayor que 2                   
            pregunta11 = 'F'!=c1 || x1>20 || x2>2;
 
            // 'F' es igual a c1 y x3 es menor que x1          
            pregunta12 = 'F'==c1 && x3<x1 ;
            
            // 'F' es igual a c1 y x3 es menor que x1 y x2 es menor o igual que x3
            pregunta13 = 'F'==c1 && x3<x1 && x2<=x3;
            
            // x2 est� entre x3 y x1, y c2 es 'S'           
            pregunta14 = x2>=x1 && x2<=x3 && c2=='S';
            
            // x3 no est� entre x2 y x1           
            pregunta15 = !(x3<=x2 && x3<=x1);
            //Otra opci�n: x3<x2 || x3>x1
                    
            // x2 no est� entre x3 y x1, o c2 es igual a c1          
            pregunta16 = !(x3<=x2 && x3<=x1) || c2 == c1;

            // no se cumple que x3 es menor que x1
            pregunta17 = ! (x3<x1);
            
            // ni x3 es mayor que x1, ni c2 es distinto a c1
            pregunta18 = !(x3>x1) && !(c2!=c1) ;            

            // no se cumple que x1 es menor que 100 y x2 es mayor que 10          
            pregunta19 = x1 < 100 && x2 >10 ;
            
            // c2 es anterior alfab�ticamente a c1                      
            pregunta20 = c2 < c1; 
            
            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println("-------------------------------------");
            System.out.println (" 1. x1 es igual a x2: " + pregunta1);
            System.out.println (" 2. c1 es distinto a c2: " + pregunta2);
            System.out.println (" 3. x1 est� entre 10 y 100: " + pregunta3);
            System.out.println (" 4. x2 no est� entre 10 y 100: " + pregunta4);
            System.out.println (" 5. x3 no est� entre 10 y 100: " + pregunta5);

            System.out.println (" 6. x1 es mayor que x2 y c1 es igual a c2: " + pregunta6);
            System.out.println (" 7. O x1 es mayor que x2, o c1 es distinto a c2, cualquiera de los dos casos: " + pregunta7);
            System.out.println (" 8.x1 es menor o igual que 7 y c2 es igual a c1 : " + pregunta8 );
            System.out.println (" 9.c2 es distinto de 'A' y x2 es mayor que 0: " + pregunta8 );
            System.out.println ("10.'F' es distinto de c1 o x1 es mayor que 20: " + pregunta10 );

            System.out.println ("11.'F' es distinto de c1 o x1 es mayor que 20 o x2 es mayor que 2: " + pregunta11 );
            System.out.println ("12.'F' es igual a c1 y x3 es menor que x1: " + pregunta12 );
            System.out.println ("13.'F' es igual a c1 y x3 es menor que x1 y x2 es menor o igual que x3: " + pregunta13 );
            System.out.println ("14.x2 est� entre x3 y x1, y c2 es 'S': " + pregunta14 );
            System.out.println ("15.x3 no est� entre x2 y x1: " + pregunta15 );

            System.out.println ("16.x2 no est� entre x3 y x1, o c2 es igual a c1: " + pregunta16 );
            System.out.println ("17.no se cumple que x3 es menor que x1: " + pregunta17 );
            System.out.println ("18.ni x3 es mayor que x1, ni c2 es distinto a c1: " + pregunta18 );
            System.out.println ("19.no se cumple que x1 es menor que 100 y x2 es mayor que 10: " + pregunta19 );
            System.out.println ("20.c2 es anterior alfab�ticamente a c1: " + pregunta20 );
                    

 
        
	}
    
}