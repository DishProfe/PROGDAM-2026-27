
package ejemplos;

/**
 * Programa CUADERNOS DE HOJAS DE COLORES
 * @author diosdado
 */

import java.util.Scanner;


public class Cuaderno02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int numHojas = 61;

            // Variables de salida
            int numHojasRojas;
            int numHojasVerdes;

            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CUADERNOS DE HOJAS DE COLORES");
            System.out.println("-----------------------------");
            System.out.println("El cuaderno tiene: " + numHojas + " hojas");

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            numHojasRojas = numHojas / 2 + numHojas % 2;
            numHojasVerdes = numHojas / 2;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero total de hojas: " + numHojas);
            System.out.println ("N�mero de hojas rojas: " + numHojasRojas);
            System.out.println ("N�mero de hojas verdes: " + numHojasVerdes);

        
	}
    
}