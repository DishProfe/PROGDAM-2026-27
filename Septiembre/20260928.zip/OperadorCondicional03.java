
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperadorCondicional03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            //d contendr� un n�mero aleatorio entre 0 y 100.
            double d=Math.random()*100;



            // Variables de salida
            String respuesta;

            // Variables auxiliares
            final String AFIRMACION1 = "entre 0 y 20";
            final String AFIRMACION2 = "entre 20 y 50";
            final String AFIRMACION3 = "entre 50 y 75";
            final String AFIRMACION4 = "entre 75 y 100";
            String respuesta1, respuesta2, respuesta3, respuesta4;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE OPERADOR CONDICIONAL (?:)");
            System.out.println("-------------------------------------");
            System.out.println("N�mero aleatorio generado d= " + d);

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            respuesta1 = d>=0.0 && d<20.0 ? AFIRMACION1 : "";
            respuesta2 = d>=20.0 && d<=50.0 ? AFIRMACION2 : "";
            respuesta3 = d>50.0 && d<75.0 ? AFIRMACION3 : "";
            respuesta4 = d>=75.0 && d<=100.0 ? AFIRMACION4 : "";

            respuesta = respuesta1 + respuesta2 + respuesta3 + respuesta4;            
            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println( respuesta );
        
	}
    
}