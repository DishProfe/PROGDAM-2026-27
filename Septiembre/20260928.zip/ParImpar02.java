
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class ParImpar02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esPar;
            String resultado;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE PARIDAD");
            System.out.println("----------------------");
            System.out.println("Introduzca un n�mero entero: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            //esPar = numero % 2 == 0;
            //resultado = esPar ? "par" : "impar";

            resultado =  numero % 2 == 0 ? "par" : "impar";
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero " + numero + " es " + resultado);

            System.out.println ("El n�mero " + numero + " es " + (numero % 2 == 0 ? "par" : "impar") );
            
            
	}
    
}