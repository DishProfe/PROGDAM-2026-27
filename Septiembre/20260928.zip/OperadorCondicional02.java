
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperadorCondicional02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            //d contendr� un n�mero aleatorio entre 0 y 100.
            double d=Math.random()*100;



            // Variables de salida
            boolean respuesta1, respuesta2, respuesta3, respuesta4;
            String respuesta;
            

            // Variables auxiliares
            final String AFIRMACION1 = "entre 0 y 20";
            final String AFIRMACION2 = "entre 20 y 50";
            final String AFIRMACION3 = "entre 50 y 75";
            final String AFIRMACION4 = "entre 75 y 100";

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE OPERADOR CONDICIONAL (?:)");
            System.out.println("-------------------------------------");
            System.out.println("N�mero aleatorio generado d= " + d);

            //----------------------------------------------
            //                 Procesamiento 
            //                       +
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            respuesta = d>=0.0 && d<20.0 ? AFIRMACION1 : "No " + AFIRMACION1;
            System.out.println (respuesta);
            
            respuesta = d>=20.0 && d<=50.0 ? AFIRMACION2 : "No " + AFIRMACION2;
            System.out.println (respuesta);

            respuesta = d>50.0 && d<75.0 ? AFIRMACION3 : "No " + AFIRMACION3;
            System.out.println (respuesta);

            respuesta = d>=75.0 && d<=100.0 ? AFIRMACION4 : "No " + AFIRMACION4 ;
            System.out.println (respuesta);



        
	}
    
}