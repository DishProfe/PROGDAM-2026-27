
package ejemplos;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class OperadorCondicional01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            //d contendr� un n�mero aleatorio entre 0 y 100.
            double d=Math.random()*100;



            // Variables de salida
            boolean respuesta1, respuesta2, respuesta3, respuesta4;


            // Variables auxiliares
            final String PREGUNTA1 = "d est� entre 0 y 20, 20 no incluido";
            final String PREGUNTA2 = "d est� entre 20 y 50, ambos incluidos";
            final String PREGUNTA3 = "d est� entre 50 y 75, ninguno incluido";
            final String PREGUNTA4 = "d est� entre 75 y 100, ambos incluidos";

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE OPERADOR CONDICIONAL (?:)");
            System.out.println("-------------------------------------");
            System.out.println("N�mero aleatorio generado d= " + d);

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            respuesta1 = d>=0.0 && d<20.0;
            respuesta2 = d>=20.0 && d<=50.0;
            respuesta3 = d>50.0 && d<75.0;
            respuesta4 = d>=75.0 && d<=100.0;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (PREGUNTA1 + ": " + respuesta1);
            System.out.println (PREGUNTA2 + ": " + respuesta2);
            System.out.println (PREGUNTA3 + ": " + respuesta3);
            System.out.println (PREGUNTA4 + ": " + respuesta4);

        
	}
    
}