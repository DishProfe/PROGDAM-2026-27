
package ejemplos;

/**
 * Programa Comprobador de hora v�lida
 * @author diosdado
 */

import java.util.Scanner;


public class HoraValida01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int horas, minutos, segundos;

            // Variables de salida
            boolean tiempoValido;


            // Variables auxiliares
            boolean horasValidas, minutosValidos, segundosValidos;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE HORA V�LIDA");
            System.out.println("--------------------------");
            System.out.print("Introduzca horas: ");
            horas = teclado.nextInt();
            System.out.print("Introduzca minutos: ");
            minutos = teclado.nextInt();
            System.out.print("Introduzca segundos: ");
            segundos = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            segundosValidos = segundos>=0 && segundos<=59;
            minutosValidos = minutos>=0 && minutos<=59;
            horasValidas = horas>=0 && horas<=23;

            tiempoValido = segundosValidos && minutosValidos && horasValidas;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La hora es valida: " + tiempoValido);

        
	}
    
}