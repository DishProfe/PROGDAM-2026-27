
package ejemplos;

/**
 * Programa COMPROBADOR DE FECHAS V�LIDAS
 * @author diosdado
 */

import java.util.Scanner;


public class FechaValida02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int ANIO_MIN = 1900;
            final int ANIO_MAX = 2100;

            // Variables de entrada
            int anio, mes, dia;

            // Variables de salida
            boolean fechaValida;
            String resultado;


            // Variables auxiliares
            boolean anioValido, mesValido, diaValido;
            boolean esMes30;
            int diaMax;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE FECHAS V�LIDAS");
            System.out.println("-----------------------------");
            System.out.println("Suponemos que todos los meses tienen 30 d�as");

            System.out.print("Introduzca a�o: ");
            anio = teclado.nextInt();
            System.out.print("Introduzca mes: ");
            mes = teclado.nextInt();
            System.out.print("Introduzca d�a: ");
            dia = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            anioValido = anio>=ANIO_MIN && anio<=ANIO_MAX;
                     
            mesValido = mes>=1 && mes<=12;
                        
            esMes30 = mes==2 || mes==4 || mes==6 || mes==9 || mes==11;
            diaMax = esMes30 ? 30 : 31;
            
            diaValido = dia>=1 && dia<=diaMax ;
            
            fechaValida = anioValido && mesValido && diaValido;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("La fecha %02d/%02d/%04d " + (fechaValida ? "" : "no ")  +  "es v�lida.\n",
                    dia, mes, anio);

        
	}
    
}