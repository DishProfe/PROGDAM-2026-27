
package ejemplos;

/**
 * Programa Comprobador de hora v�lida
 * @author diosdado
 */

import java.util.Scanner;


public class HoraValida05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int horas, minutos, segundos;

            // Variables de salida
            boolean tiempoValido;
            String resultado;


            // Variables auxiliares
            boolean horasValidas, minutosValidos, segundosValidos;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE HORA V�LIDA");
            System.out.println("--------------------------");
            System.out.print("Introduzca horas: ");
            horas = teclado.nextInt();
            System.out.print("Introduzca minutos: ");
            minutos = teclado.nextInt();
            System.out.print("Introduzca segundos: ");
            segundos = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            segundosValidos = segundos>=0 && segundos<=59;
            minutosValidos = minutos>=0 && minutos<=59;
            horasValidas = horas>=0 && horas<=23;

            tiempoValido = segundosValidos && minutosValidos && horasValidas;
            
            //resultado = tiempoValido ? "s�" : "no";
            resultado = tiempoValido ? "" : "no ";
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("La hora introducida es: %02d:%02d:%02d\n", horas, minutos, segundos);
            System.out.println ("La hora es v�lida: " + tiempoValido);
            System.out.println ("La hora " + (tiempoValido ? "" : "no ") + "es v�lida.");

        
	}
    
}